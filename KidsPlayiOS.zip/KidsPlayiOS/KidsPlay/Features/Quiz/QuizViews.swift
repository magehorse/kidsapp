import SwiftUI

// MARK: - Engine (pure logic - unit tested)

struct QuizQuestion: Equatable {
    let correct: LearningItem
    /// Shuffled options, always contains `correct` exactly once.
    let options: [LearningItem]

    var correctIndex: Int { options.firstIndex(of: correct) ?? 0 }
}

enum QuizEngine {
    /// Builds a question with up to `optionCount` distinct options.
    /// Android used `do { ... } while (list.size() != 4)` which loops forever if a category had < 4 items;
    /// this version can never hang and never repeats the previous answer back-to-back.
    static func makeQuestion<G: RandomNumberGenerator>(
        from items: [LearningItem],
        optionCount: Int = 4,
        avoiding previous: LearningItem? = nil,
        using generator: inout G
    ) -> QuizQuestion? {
        guard items.count >= 2 else { return nil }

        var candidateIndices = Array(items.indices)
        if let previous, items.count > 2 {
            candidateIndices.removeAll { items[$0] == previous }
        }
        guard let correctIndex = candidateIndices.randomElement(using: &generator) else { return nil }

        let distractors = items.indices
            .filter { $0 != correctIndex }
            .shuffled(using: &generator)
            .prefix(max(1, min(optionCount, items.count) - 1))

        let correct = items[correctIndex]
        var options = distractors.map { items[$0] }
        options.append(correct)
        options.shuffle(using: &generator)
        return QuizQuestion(correct: correct, options: options)
    }

    static func makeQuestion(from items: [LearningItem], avoiding previous: LearningItem? = nil) -> QuizQuestion? {
        var rng = SystemRandomNumberGenerator()
        return makeQuestion(from: items, avoiding: previous, using: &rng)
    }
}

// MARK: - Shared session state

@Observable
final class QuizSession {
    private(set) var question: QuizQuestion?
    private(set) var wrongIndices: Set<Int> = []
    private(set) var solvedIndex: Int?
    private(set) var shakeTick = 0
    private let items: [LearningItem]

    init(items: [LearningItem]) {
        self.items = items
        next()
    }

    var isSolved: Bool { solvedIndex != nil }

    func next() {
        question = QuizEngine.makeQuestion(from: items, avoiding: question?.correct)
        wrongIndices = []
        solvedIndex = nil
    }

    /// Returns true when the tap was the right answer.
    @discardableResult
    func choose(_ index: Int) -> Bool {
        guard let question, !isSolved, !wrongIndices.contains(index) else { return false }
        if index == question.correctIndex {
            solvedIndex = index
            return true
        }
        wrongIndices.insert(index)
        shakeTick += 1
        return false
    }
}

private struct ShakeEffect: GeometryEffect {
    var travel: CGFloat = 8
    var animatableData: CGFloat
    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(CGAffineTransform(translationX: travel * sin(animatableData * .pi * 4), y: 0))
    }
}

private enum OptionStatus { case idle, correct, wrong }

private func borderColor(_ status: OptionStatus) -> Color {
    switch status {
    case .idle: return .white
    case .correct: return Theme.correctGreen
    case .wrong: return Theme.wrongRed
    }
}

// MARK: - Look & Choose  (LookChooseActivity)

/// A picture is shown; the child picks its name.
struct LookChooseView: View {
    let categoryID: Int
    let title: String
    @State private var session: QuizSession?
    @State private var shakes: [Int: CGFloat] = [:]

    var body: some View {
        ScreenScaffold(title: title) {
            if let session, let question = session.question {
                VStack(spacing: 18) {
                    KidImage(name: question.correct.image)
                        .padding(20)
                        .frame(maxWidth: .infinity)
                        .frame(height: 230)
                        .background(.white, in: RoundedRectangle(cornerRadius: 28))
                        .shadow(color: .black.opacity(0.1), radius: 6, y: 3)
                        .padding(.horizontal, 20)
                        .id(question.correct.image)
                        .transition(.scale.combined(with: .opacity))

                    Text(session.isSolved ? "Great job! 🎉" : "What is this?")
                        .font(Theme.font(20, relativeTo: .title3))
                        .foregroundStyle(session.isSolved ? Theme.correctGreen : Theme.neutralText)

                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)], spacing: 14) {
                        ForEach(Array(question.options.enumerated()), id: \.offset) { index, option in
                            optionButton(session: session, index: index, option: option)
                        }
                    }
                    .padding(.horizontal, 20)

                    Spacer(minLength: 0)
                    nextButton(session: session)
                }
                .padding(.top, 8)
                .animation(.spring(response: 0.4, dampingFraction: 0.7), value: question)
            } else {
                Text("Nothing to play yet").foregroundStyle(.secondary)
            }
        }
        .task { if session == nil { session = QuizSession(items: LearningRepository.shared.items(for: categoryID)) } }
    }

    private func status(_ session: QuizSession, _ index: Int) -> OptionStatus {
        if session.solvedIndex == index { return .correct }
        if session.wrongIndices.contains(index) { return .wrong }
        return .idle
    }

    private func optionButton(session: QuizSession, index: Int, option: LearningItem) -> some View {
        let state = status(session, index)
        return Button {
            let correct = session.choose(index)
            if correct {
                Haptics.success()
                SpeechService.shared.speak(option.speak)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) {
                    if session.isSolved { withAnimation { session.next() } }
                }
            } else if session.wrongIndices.contains(index) {
                Haptics.error()
                withAnimation(.linear(duration: 0.4)) { shakes[index, default: 0] += 1 }
            }
        } label: {
            Text(option.speak)
                .font(Theme.font(20, relativeTo: .title3))
                .foregroundStyle(state == .idle ? Theme.neutralText : .white)
                .minimumScaleFactor(0.6)
                .lineLimit(2)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity, minHeight: 74)
                .padding(.horizontal, 8)
                .background(
                    RoundedRectangle(cornerRadius: 22)
                        .fill(state == .correct ? Theme.correctGreen : state == .wrong ? Theme.wrongRed : Color.white)
                )
                .overlay(RoundedRectangle(cornerRadius: 22).stroke(borderColor(state), lineWidth: 3))
                .shadow(color: .black.opacity(0.08), radius: 4, y: 2)
        }
        .buttonStyle(PressableStyle())
        .modifier(ShakeEffect(animatableData: shakes[index, default: 0]))
        .disabled(session.isSolved)
        .accessibilityLabel(option.speak)
    }

    private func nextButton(session: QuizSession) -> some View {
        Button {
            withAnimation { session.next() }
        } label: {
            Label("Next", systemImage: "arrow.right.circle.fill")
                .font(Theme.font(18, relativeTo: .headline))
                .foregroundStyle(.white)
                .padding(.horizontal, 30).padding(.vertical, 12)
                .background(Theme.primaryBlue, in: Capsule())
        }
        .padding(.bottom, 12)
    }
}

// MARK: - Listen & Guess  (ListenGuessActivity)

/// A word is spoken (and shown); the child taps the matching picture.
struct ListenGuessView: View {
    let categoryID: Int
    let title: String
    @State private var session: QuizSession?
    @State private var shakes: [Int: CGFloat] = [:]
    @State private var pulse = false

    var body: some View {
        ScreenScaffold(title: title) {
            if let session, let question = session.question {
                VStack(spacing: 14) {
                    Button { SpeechService.shared.speak(question.correct.title, force: true) } label: {
                        Image(systemName: "speaker.wave.3.fill")
                            .font(.system(size: 44, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 120, height: 120)
                            .background(Theme.primaryBlue, in: Circle())
                            .overlay(Circle().stroke(Theme.sunYellow, lineWidth: 4))
                            .scaleEffect(pulse ? 1.06 : 0.96)
                            .shadow(color: .black.opacity(0.2), radius: 6, y: 3)
                    }
                    .accessibilityLabel("Hear the word again")

                    Text(question.correct.title)
                        .font(Theme.font(30, relativeTo: .title))
                        .foregroundStyle(Theme.titleLetters[abs(question.correctIndex) % Theme.titleLetters.count])
                        .minimumScaleFactor(0.5).lineLimit(1)

                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)], spacing: 14) {
                        ForEach(Array(question.options.enumerated()), id: \.offset) { index, option in
                            optionButton(session: session, index: index, option: option)
                        }
                    }
                    .padding(.horizontal, 20)

                    Spacer(minLength: 0)
                    Button { withAnimation { session.next() }; speakCurrent() } label: {
                        Label("Next", systemImage: "arrow.right.circle.fill")
                            .font(Theme.font(18, relativeTo: .headline))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 30).padding(.vertical, 12)
                            .background(Theme.primaryBlue, in: Capsule())
                    }
                    .padding(.bottom, 12)
                }
                .padding(.top, 4)
            } else {
                Text("Nothing to play yet").foregroundStyle(.secondary)
            }
        }
        .task {
            if session == nil {
                session = QuizSession(items: LearningRepository.shared.items(for: categoryID))
                speakCurrent()
            }
            withAnimation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true)) { pulse = true }
        }
        .onDisappear { SpeechService.shared.stop() }
    }

    private func speakCurrent() {
        if let word = session?.question?.correct.title { SpeechService.shared.speak(word) }
    }

    private func optionButton(session: QuizSession, index: Int, option: LearningItem) -> some View {
        let state: OptionStatus = session.solvedIndex == index ? .correct : (session.wrongIndices.contains(index) ? .wrong : .idle)
        return Button {
            let correct = session.choose(index)
            if correct {
                Haptics.success()
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) {
                    if session.isSolved { withAnimation { session.next() }; speakCurrent() }
                }
            } else if session.wrongIndices.contains(index) {
                Haptics.error()
                withAnimation(.linear(duration: 0.4)) { shakes[index, default: 0] += 1 }
            }
        } label: {
            KidImage(name: option.image)
                .padding(10)
                .frame(maxWidth: .infinity)
                .frame(height: 150)
                .background(
                    RoundedRectangle(cornerRadius: 22)
                        .fill(state == .correct ? Theme.correctGreen.opacity(0.25) : state == .wrong ? Theme.wrongRed.opacity(0.25) : Color.white)
                )
                .overlay(RoundedRectangle(cornerRadius: 22).stroke(borderColor(state), lineWidth: 4))
                .shadow(color: .black.opacity(0.08), radius: 4, y: 2)
        }
        .buttonStyle(PressableStyle())
        .modifier(ShakeEffect(animatableData: shakes[index, default: 0]))
        .disabled(session.isSolved)
        .accessibilityLabel(option.speak)
    }
}
