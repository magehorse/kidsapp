import SwiftUI

// MARK: - Splash

struct SplashView: View {
    @State private var bounce = false

    var body: some View {
        ZStack {
            Theme.headerGradient.ignoresSafeArea()
            VStack(spacing: 18) {
                Text("🎈")
                    .font(.system(size: 92))
                    .scaleEffect(bounce ? 1.12 : 0.92)
                    .animation(.easeInOut(duration: 0.7).repeatForever(autoreverses: true), value: bounce)
                Text("Kids Learning")
                    .font(Theme.font(34, relativeTo: .largeTitle))
                    .foregroundStyle(.white)
                Text("Let's learn and play! ⭐")
                    .font(Theme.font(15, relativeTo: .body))
                    .foregroundStyle(Color(hex: 0xFFE082))
            }
        }
        .onAppear { bounce = true }
    }
}

// MARK: - Home

struct HomeView: View {
    @Environment(Router.self) private var router
    @Environment(AppSettings.self) private var settings

    @State private var query = ""
    @State private var sections: [HomeSection] = []
    @State private var showNamePrompt = false
    @State private var nameDraft = ""
    @State private var update: AppUpdateInfo?
    @State private var updateGate = false
    @State private var pendingStoreURL: URL?

    private let topTitles = ["Alphabets & Numbers", "Video", "Quiz", "Mathematics"]
    private let topIcons = ["blocks", "play", "quiz", "math"]
    private let topSymbols = ["textformat.abc", "play.rectangle.fill", "questionmark.bubble.fill", "plus.forwardslash.minus"]

    private var visibleSections: [HomeSection] {
        sections.compactMap { $0.filtered(matching: query) }
    }

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            Theme.pageGradient.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 0) {
                    header
                    searchBar
                    sectionHeading("Top Category", accent: Color(hex: 0xFFB300))
                    topCategoryGrid
                    ForEach(Array(visibleSections.enumerated()), id: \.element.id) { index, section in
                        SectionRow(section: section, accent: Theme.sectionAccents[index % Theme.sectionAccents.count],
                                   onViewAll: { viewAll(section) },
                                   onItem: { open(section, item: $0) })
                    }
                    Color.clear.frame(height: 110)   // room for FAB + banner
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .ignoresSafeArea(edges: .top)

            reelButton
                .padding(.trailing, 18)
                .padding(.bottom, 62)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) { BannerAdView() }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .task {
            if sections.isEmpty { sections = HomeSections.make(drawPreview: DrawingCatalog.pictures(easy: true)) }
            AdService.shared.preloadInterstitial()
            if settings.userName.trimmingCharacters(in: .whitespaces).isEmpty { showNamePrompt = true }
            update = await UpdateChecker.newerVersionAvailable()
        }
        .alert("What's your name?", isPresented: $showNamePrompt) {
            TextField("Champ", text: $nameDraft)
            Button("Let's go!") {
                let trimmed = nameDraft.trimmingCharacters(in: .whitespaces)
                settings.userName = trimmed.isEmpty ? "Champ" : trimmed
            }
        } message: {
            Text("We'll say hello every time you open the app.")
        }
        .sheet(item: $update) { info in
            UpdateSheet(info: info) {
                pendingStoreURL = info.storeURL
                // wait for the sheet to finish dismissing before presenting the gate
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { updateGate = true }
            }
            .presentationDetents([.height(260)])
        }
        .parentalGate(isPresented: $updateGate) {
            if let url = pendingStoreURL { UIApplication.shared.open(url) }
        }
    }

    // MARK: Pieces

    private var displayName: String {
        settings.userName.isEmpty ? "Champ" : settings.userName
    }

    private var header: some View {
        ZStack(alignment: .topLeading) {
            Theme.headerGradient
                .clipShape(UnevenRoundedRectangle(bottomLeadingRadius: 32, bottomTrailingRadius: 32))
            Circle().fill(.white.opacity(0.2)).frame(width: 130).offset(x: 250, y: -20)
            Circle().fill(.white.opacity(0.2)).frame(width: 70).offset(x: 20, y: 90)

            HStack(spacing: 14) {
                Text(String(displayName.prefix(1)).uppercased())
                    .font(Theme.font(26, relativeTo: .title))
                    .foregroundStyle(Theme.headerBottom)
                    .frame(width: 58, height: 58)
                    .background(Theme.sunYellow, in: Circle())
                    .overlay(Circle().stroke(.white, lineWidth: 3))

                VStack(alignment: .leading, spacing: 2) {
                    Text("Hello 👋").font(.subheadline).foregroundStyle(.white.opacity(0.85))
                    Text("\(displayName)!")
                        .font(Theme.font(24, relativeTo: .title))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                    Text("Let's learn and play! ⭐")
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(Color(hex: 0xFFE082))
                }
                Spacer()
                Button { router.push(.settings) } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 42, height: 42)
                        .background(.white.opacity(0.25), in: Circle())
                }
                .accessibilityLabel("Settings")
            }
            .padding(.horizontal, 20)
            .padding(.top, 70)
            .padding(.bottom, 30)
        }
        .frame(maxWidth: .infinity)
    }

    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(.gray)
            TextField("Search Here", text: $query)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)
            if !query.isEmpty {
                Button { query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.gray) }
                    .accessibilityLabel("Clear search")
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 50)
        .background(.white, in: RoundedRectangle(cornerRadius: 25))
        .shadow(color: .black.opacity(0.12), radius: 6, y: 3)
        .padding(.horizontal, 18)
        .padding(.top, -24)
        .padding(.bottom, 14)
    }

    private func sectionHeading(_ title: String, accent: Color) -> some View {
        HStack(spacing: 8) {
            RoundedRectangle(cornerRadius: 4).fill(accent).frame(width: 6, height: 24)
            Text(title).font(Theme.font(19, relativeTo: .title3)).foregroundStyle(Theme.primaryBlue)
            Spacer()
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 6)
    }

    private var topCategoryGrid: some View {
        LazyVGrid(columns: KidGrid.columns(minimum: 150), spacing: 14) {
            ForEach(0..<topTitles.count, id: \.self) { index in
                Button { openTopCategory(index) } label: {
                    VStack(spacing: 8) {
                        if UIImage(named: topIcons[index]) != nil {
                            Image(topIcons[index]).resizable().scaledToFit().frame(height: 74)
                        } else {
                            Image(systemName: topSymbols[index])
                                .font(.system(size: 48, weight: .bold))
                                .foregroundStyle(.white)
                                .frame(height: 74)
                        }
                        Text(topTitles[index])
                            .font(Theme.font(15, relativeTo: .subheadline))
                            .foregroundStyle(Theme.neutralText)
                            .multilineTextAlignment(.center)
                            .minimumScaleFactor(0.8)
                    }
                    .frame(maxWidth: .infinity, minHeight: 140)
                    .padding(.vertical, 10)
                    .background(Theme.topCategoryColors[index], in: RoundedRectangle(cornerRadius: 26, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(.white, lineWidth: 3))
                    .shadow(color: .black.opacity(0.10), radius: 5, y: 3)
                }
                .buttonStyle(PressableStyle())
                .accessibilityLabel(topTitles[index])
            }
        }
        .padding(.horizontal, 18)
        .padding(.bottom, 10)
    }

    private var reelButton: some View {
        Button { router.push(.reels) } label: {
            Image(systemName: "play.tv.fill")
                .font(.system(size: 26, weight: .bold))
                .foregroundStyle(Theme.headerBottom)
                .frame(width: 62, height: 62)
                .background(.white, in: Circle())
                .overlay(Circle().stroke(Theme.sunYellow, lineWidth: 3))
                .shadow(color: .black.opacity(0.2), radius: 6, y: 3)
        }
        .accessibilityLabel("Kids Reel")
    }

    // MARK: Navigation (MainActivity.startNextActivity / SectionListener)

    private func openTopCategory(_ index: Int) {
        // Only these four tiles ever trigger an interstitial (if ads are enabled at all).
        HomeAdGate.run {
            switch index {
            case 0: router.push(.categoryGrid(type: 1))
            case 1: router.push(.videos)
            case 2: router.push(.categoryGrid(type: 2))
            default: router.push(.mathsWorld)
            }
        }
    }

    private func viewAll(_ section: HomeSection) {
        switch section.action {
        case .video: router.push(.videos)
        case .writingList: router.push(.numberList)
        case .patternList: router.push(.patternLevels)
        case .drawList: router.push(.drawPicker)
        case .subActivity: router.push(.categoryGrid(type: 1))
        }
    }

    private func open(_ section: HomeSection, item: HomeSection.Item) {
        switch section.action {
        case .video:
            router.push(.videos)
        case .writingList:
            router.push(.traceNumber(start: item.position))
        case .patternList:
            router.push(.matchingGame(roundSize: item.position))
        case .drawList:
            router.push(.drawEditor(easy: true, index: item.position))
        case .subActivity:
            // Golden Words tiles all open category 20, Lines all open 21: show the category name, not the tile label.
            let title: String
            switch item.position {
            case 20: title = "Golden Words"
            case 21: title = "Lines"
            default: title = item.title
            }
            router.push(.subCategory(position: item.position, title: title))
        }
    }
}

// MARK: - Section row

private struct SectionRow: View {
    let section: HomeSection
    let accent: Color
    let onViewAll: () -> Void
    let onItem: (HomeSection.Item) -> Void

    var body: some View {
        VStack(spacing: 8) {
            HStack(spacing: 8) {
                RoundedRectangle(cornerRadius: 4).fill(accent).frame(width: 6, height: 22)
                Text(section.title).font(Theme.font(18, relativeTo: .title3)).foregroundStyle(Theme.primaryBlue)
                Spacer()
                Button(action: onViewAll) {
                    Text("View All")
                        .font(Theme.font(12, relativeTo: .caption))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 14).padding(.vertical, 6)
                        .background(Color(hex: 0xFF7043), in: Capsule())
                }
            }
            .padding(.horizontal, 18)

            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 12) {
                    ForEach(Array(section.items.enumerated()), id: \.offset) { _, item in
                        Button { onItem(item) } label: {
                            PictureTile(art: { art(for: item.art) })
                                .frame(width: 128, height: 128)
                        }
                        .buttonStyle(PressableStyle())
                        .accessibilityLabel(item.title.isEmpty ? section.title : item.title)
                    }
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 6)
            }
        }
        .padding(.top, 10)
    }

    @ViewBuilder
    private func art(for art: ItemArt) -> some View {
        switch art {
        case .asset(let name): KidImage(name: name)
        case .picture(let picture): DrawingThumbnail(picture: picture)
        }
    }
}

// MARK: - Update sheet (replaces the Play "update available" bottom dialog)

extension AppUpdateInfo: Identifiable {
    var id: String { latestVersion }
}

private struct UpdateSheet: View {
    let info: AppUpdateInfo
    let onUpdate: () -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 14) {
            Text("Update available 🎉").font(Theme.font(22, relativeTo: .title2))
            Text("Version \(info.latestVersion) has new games and fixes.")
                .font(.subheadline).foregroundStyle(.secondary)
            Button {
                dismiss()
                onUpdate()
            } label: {
                Text("Update").font(Theme.font(17)).frame(maxWidth: .infinity).padding(.vertical, 14)
                    .background(Theme.primaryBlue, in: Capsule()).foregroundStyle(.white)
            }
            Button("Not now") { dismiss() }
        }
        .padding(24)
    }
}
