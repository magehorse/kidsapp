import SwiftUI
import AVFoundation

// MARK: - Model + API  (ReelModel / ReelRetrofitInstance - neither was in the zip)

struct ReelModel: Decodable, Equatable {
    /// Android calls the video URL `getImage()`.
    let image: String?
    private let videoFlag: Bool?

    private enum CodingKeys: String, CodingKey {
        case image
        case isVideo = "is_video"
        case isVideoCamel = "isVideo"
        case type
    }

    init(image: String?, isVideo: Bool? = nil) {
        self.image = image
        self.videoFlag = isVideo
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        image = try c.decodeIfPresent(String.self, forKey: .image)

        func flexibleBool(_ key: CodingKeys) -> Bool? {
            if let b = try? c.decodeIfPresent(Bool.self, forKey: key) { return b }
            if let i = try? c.decodeIfPresent(Int.self, forKey: key) { return i != 0 }
            if let s = try? c.decodeIfPresent(String.self, forKey: key) {
                return ["1", "true", "video", "yes"].contains(s.lowercased())
            }
            return nil
        }
        videoFlag = flexibleBool(.isVideo) ?? flexibleBool(.isVideoCamel) ?? flexibleBool(.type)
    }

    /// If the server doesn't send a flag, fall back to the `.mp4` check Android also applies.
    var isVideo: Bool {
        videoFlag ?? (image?.lowercased().contains(".mp4") ?? false)
    }

    var videoURL: URL? {
        guard let image, !image.trimmingCharacters(in: .whitespaces).isEmpty else { return nil }
        return URL(string: image)
    }
}

enum ReelService {
    static func fetch() async throws -> [ReelModel] {
        var components = URLComponents(url: AppConfig.reelBaseURL.appendingPathComponent(AppConfig.reelEndpointPath),
                                       resolvingAgainstBaseURL: false)
        components?.queryItems = [
            URLQueryItem(name: "category_id", value: AppConfig.reelCategoryID),
            URLQueryItem(name: "type", value: AppConfig.reelType)
        ]
        guard let url = components?.url else { throw URLError(.badURL) }
        let (data, response) = try await URLSession.shared.data(from: url)
        if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            throw URLError(.badServerResponse)
        }
        return try JSONDecoder().decode([ReelModel].self, from: data)
    }
}

// MARK: - Playlist (pure logic - unit tested)

/// Endless shuffled feed: the original list never grows; whole shuffled "rounds" of it are appended
/// before the child reaches the end (Android `prepareNextRoundIfNeeded`).
struct ReelPlaylist {
    struct Entry: Identifiable, Equatable {
        let id: Int          // == position in `entries`
        let url: URL
    }

    private(set) var source: [URL] = []
    private(set) var entries: [Entry] = []

    var isEmpty: Bool { entries.isEmpty }

    static func playableURLs(from models: [ReelModel]) -> [URL] {
        models.compactMap { model in
            guard model.isVideo, let url = model.videoURL,
                  url.absoluteString.lowercased().contains(".mp4") else { return nil }
            return url
        }
    }

    mutating func load(_ urls: [URL]) {
        source = urls
        entries = []
        appendRound()
    }

    mutating func appendRound() {
        guard !source.isEmpty else { return }
        let start = entries.count
        let round = source.shuffled()
        entries += round.enumerated().map { Entry(id: start + $0.offset, url: $0.element) }
    }

    /// True when `position` is within the last two entries - time to append another round.
    func needsMore(at position: Int) -> Bool {
        !entries.isEmpty && position >= entries.count - 2
    }
}

// MARK: - Player manager

@MainActor
@Observable
final class ReelPlayerManager {
    // Not observed: players are created lazily from inside view bodies and must not trigger re-renders.
    @ObservationIgnored private var players: [Int: AVPlayer] = [:]
    @ObservationIgnored private var endObservers: [Int: NSObjectProtocol] = [:]
    @ObservationIgnored var onEnded: ((Int) -> Void)?

    func player(at index: Int, url: URL) -> AVPlayer {
        if let existing = players[index] { return existing }
        let item = AVPlayerItem(url: url)
        let player = AVPlayer(playerItem: item)
        player.actionAtItemEnd = .pause
        players[index] = player
        endObservers[index] = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.onEnded?(index) }
        }
        return player
    }

    /// Plays `index`, pauses everything else, warms up the next one and frees players that are far away.
    func activate(index: Int, entries: [ReelPlaylist.Entry]) {
        guard entries.indices.contains(index) else { return }
        configureAudioSession()

        for (i, player) in players where i != index { player.pause() }

        let current = player(at: index, url: entries[index].url)
        current.seek(to: .zero)
        current.play()

        if entries.indices.contains(index + 1) {
            _ = player(at: index + 1, url: entries[index + 1].url)   // preload
        }

        let keep = Set([index - 1, index, index + 1])
        for i in players.keys where !keep.contains(i) { release(i) }
    }

    func pauseAll() { players.values.forEach { $0.pause() } }

    func resumeCurrent(_ index: Int) { players[index]?.play() }

    func releaseAll() { for i in Array(players.keys) { release(i) } }

    private func release(_ index: Int) {
        players[index]?.pause()
        players[index]?.replaceCurrentItem(with: nil)
        players[index] = nil
        if let observer = endObservers.removeValue(forKey: index) { NotificationCenter.default.removeObserver(observer) }
    }

    private func configureAudioSession() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
        try? AVAudioSession.sharedInstance().setActive(true)
    }
}

// MARK: - Player layer

private struct PlayerLayerView: UIViewRepresentable {
    let player: AVPlayer

    final class PlayerUIView: UIView {
        override class var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }

    func makeUIView(context: Context) -> PlayerUIView {
        let view = PlayerUIView()
        view.playerLayer.videoGravity = .resizeAspect
        view.playerLayer.player = player
        view.backgroundColor = .clear
        return view
    }

    func updateUIView(_ view: PlayerUIView, context: Context) {
        if view.playerLayer.player !== player { view.playerLayer.player = player }
    }
}

// MARK: - Screen  (ReelActivity)

struct ReelView: View {
    @Environment(Router.self) private var router
    @Environment(\.scenePhase) private var scenePhase

    @State private var playlist = ReelPlaylist()
    @State private var manager = ReelPlayerManager()
    @State private var currentIndex: Int? = 0
    @State private var isLoading = true
    @State private var isWorking = false
    @State private var message: String?
    @State private var shareItem: ShareItem?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            if playlist.isEmpty {
                if isLoading { ProgressView().tint(.white).scaleEffect(1.4) }
            } else {
                pager
            }

            controls
        }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .statusBarHidden(true)
        .toast($message)
        .sheet(item: $shareItem) { item in ShareSheet(items: [item.url]) }
        .task { await load() }
        .onChange(of: currentIndex) { _, newValue in
            guard let newValue else { return }
            manager.activate(index: newValue, entries: playlist.entries)
            if playlist.needsMore(at: newValue) { playlist.appendRound() }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { manager.pauseAll() } else if let i = currentIndex { manager.resumeCurrent(i) }
        }
        .onAppear {
            manager.onEnded = { finished in
                // Next page normally exists already because rounds are appended early.
                if finished + 1 < playlist.entries.count {
                    withAnimation { currentIndex = finished + 1 }
                } else {
                    playlist.appendRound()
                    withAnimation { currentIndex = finished + 1 }
                }
            }
        }
        .onDisappear {
            manager.pauseAll()
            manager.releaseAll()
        }
    }

    private var pager: some View {
        ScrollView(.vertical, showsIndicators: false) {
            LazyVStack(spacing: 0) {
                ForEach(playlist.entries) { entry in
                    ZStack {
                        ProgressView().tint(.white.opacity(0.6))
                        PlayerLayerView(player: manager.player(at: entry.id, url: entry.url))
                    }
                    .containerRelativeFrame([.horizontal, .vertical])
                    .id(entry.id)
                }
            }
            .scrollTargetLayout()
        }
        .scrollTargetBehavior(.paging)
        .scrollPosition(id: $currentIndex)
        .ignoresSafeArea()
    }

    private var controls: some View {
        VStack {
            HStack {
                CircleIconButton(systemName: "chevron.left", label: "Back") { router.pop() }
                Spacer()
            }
            .padding(.horizontal, 16).padding(.top, 8)

            Spacer()

            HStack {
                Spacer()
                VStack(spacing: 20) {
                    reelAction("arrow.down.to.line", label: "Save reel") { Task { await download() } }
                    reelAction("square.and.arrow.up", label: "Share reel") { Task { await share() } }
                }
                .padding(.trailing, 16)
                .padding(.bottom, 60)
            }
        }
        .overlay { if isWorking { ProgressView().tint(.white).scaleEffect(1.5) } }
    }

    private func reelAction(_ symbol: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 52, height: 52)
                .background(.black.opacity(0.45), in: Circle())
        }
        .disabled(isWorking || playlist.isEmpty)
        .accessibilityLabel(label)
    }

    // MARK: Actions

    private func load() async {
        isLoading = true
        defer { isLoading = false }
        do {
            let urls = ReelPlaylist.playableURLs(from: try await ReelService.fetch())
            guard !urls.isEmpty else { message = "No reels found"; return }
            playlist.load(urls)
            currentIndex = 0
            // give the pager a beat to lay out before autoplay (Android delayed 300ms too)
            try? await Task.sleep(for: .milliseconds(300))
            manager.activate(index: 0, entries: playlist.entries)
            if playlist.needsMore(at: 0) { playlist.appendRound() }
        } catch {
            message = error.localizedDescription.isEmpty ? "Something went wrong" : error.localizedDescription
        }
    }

    private var currentURL: URL? {
        guard let i = currentIndex, playlist.entries.indices.contains(i) else { return nil }
        return playlist.entries[i].url
    }

    private func download() async {
        guard let url = currentURL else { return }
        isWorking = true
        defer { isWorking = false }
        do {
            let file = try await RemoteFile.download(url, fileExtension: "mp4")
            try await PhotoLibrary.saveVideo(at: file)
            try? FileManager.default.removeItem(at: file)
            message = "Saved to your Photos"
        } catch {
            message = (error as? LocalizedError)?.errorDescription ?? "Could not start download"
        }
    }

    /// The system share sheet includes WhatsApp when installed (iOS cannot target a specific app directly).
    private func share() async {
        guard let url = currentURL else { return }
        isWorking = true
        defer { isWorking = false }
        do {
            let file = try await RemoteFile.download(url, fileExtension: "mp4")
            shareItem = ShareItem(url: file)
        } catch {
            message = "Could not share: \(error.localizedDescription)"
        }
    }
}
