import SwiftUI
import UIKit

// MARK: - Glyph sampling (pure logic - unit tested)

/// A rendered digit plus the points inside it that must be "touched" for the number to count as traced.
struct GlyphSample {
    /// Black glyph on transparent background, `sideLength` x `sideLength` points (scale 1).
    let image: UIImage
    /// Sample points in the image's own coordinate space (0...sideLength).
    let points: [CGPoint]
    let sideLength: CGFloat
    /// Touch distance (in image space) that counts as covering a sample point.
    let coverRadius: CGFloat
}

enum GlyphSampler {
    static func make(text: String, side: CGFloat = 320, step: CGFloat = 6) -> GlyphSample {
        let font = roundedHeavyFont(size: side * 0.9)
        let attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.black]
        let textSize = (text as NSString).size(withAttributes: attributes)

        // Pass 1: render large and find the real ink bounds, so every digit ends up optically centred.
        let scratchSide = side * 2
        let origin = CGPoint(x: (scratchSide - textSize.width) / 2, y: (scratchSide - textSize.height) / 2)
        let scratch = render(size: CGSize(width: scratchSide, height: scratchSide)) { ctx in
            (text as NSString).draw(at: origin, withAttributes: attributes)
            _ = ctx
        }
        let ink = inkBounds(of: scratch) ?? CGRect(x: 0, y: 0, width: scratchSide, height: scratchSide)

        // Pass 2: draw scaled and centred into the final square.
        let target = side * 0.84
        let scale = min(target / max(ink.width, 1), target / max(ink.height, 1))
        let final = render(size: CGSize(width: side, height: side)) { ctx in
            ctx.translateBy(x: side / 2, y: side / 2)
            ctx.scaleBy(x: scale, y: scale)
            ctx.translateBy(x: -ink.midX, y: -ink.midY)
            (text as NSString).draw(at: origin, withAttributes: attributes)
        }

        let points = samplePoints(in: final, step: step)
        return GlyphSample(image: final, points: points, sideLength: side, coverRadius: side * 0.075)
    }

    // MARK: helpers

    private static func roundedHeavyFont(size: CGFloat) -> UIFont {
        let base = UIFont.systemFont(ofSize: size, weight: .heavy)
        if let descriptor = base.fontDescriptor.withDesign(.rounded) {
            return UIFont(descriptor: descriptor, size: size)
        }
        return base
    }

    private static func render(size: CGSize, _ draw: (CGContext) -> Void) -> UIImage {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = false
        return UIGraphicsImageRenderer(size: size, format: format).image { draw($0.cgContext) }
    }

    /// RGBA bytes of an image (premultiplied), plus its pixel size.
    private static func pixels(of image: UIImage) -> (bytes: [UInt8], width: Int, height: Int)? {
        guard let cg = image.cgImage else { return nil }
        let width = cg.width, height = cg.height
        var bytes = [UInt8](repeating: 0, count: width * height * 4)
        let drawn: Bool = bytes.withUnsafeMutableBytes { raw in
            guard let context = CGContext(
                data: raw.baseAddress, width: width, height: height, bitsPerComponent: 8,
                bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
            ) else { return false }
            context.draw(cg, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        return drawn ? (bytes, width, height) : nil
    }

    private static func inkBounds(of image: UIImage) -> CGRect? {
        guard let (bytes, width, height) = pixels(of: image) else { return nil }
        var minX = width, minY = height, maxX = -1, maxY = -1
        for y in 0..<height {
            for x in 0..<width where bytes[(y * width + x) * 4 + 3] > 40 {
                minX = min(minX, x); maxX = max(maxX, x)
                minY = min(minY, y); maxY = max(maxY, y)
            }
        }
        guard maxX >= minX, maxY >= minY else { return nil }
        return CGRect(x: minX, y: minY, width: maxX - minX + 1, height: maxY - minY + 1)
    }

    private static func samplePoints(in image: UIImage, step: CGFloat) -> [CGPoint] {
        guard let (bytes, width, height) = pixels(of: image) else { return [] }
        var points: [CGPoint] = []
        var y: CGFloat = step / 2
        while y < CGFloat(height) {
            var x: CGFloat = step / 2
            while x < CGFloat(width) {
                let index = (Int(y) * width + Int(x)) * 4 + 3
                if bytes[index] > 128 { points.append(CGPoint(x: x, y: y)) }
                x += step
            }
            y += step
        }
        return points
    }
}

/// Tracks how much of a glyph has been covered by the child's finger.
struct TraceProgress {
    private(set) var covered: [Bool]
    private(set) var coveredCount = 0
    let sample: GlyphSample
    /// Fraction of the glyph that must be covered to count as "traced". Forgiving on purpose.
    let completionThreshold: Double

    init(sample: GlyphSample, completionThreshold: Double = 0.85) {
        self.sample = sample
        self.completionThreshold = completionThreshold
        self.covered = Array(repeating: false, count: sample.points.count)
    }

    var fraction: Double {
        sample.points.isEmpty ? 0 : Double(coveredCount) / Double(sample.points.count)
    }

    var isComplete: Bool { fraction >= completionThreshold }

    /// `point` is in glyph image space.
    mutating func touch(_ point: CGPoint) {
        let r2 = sample.coverRadius * sample.coverRadius
        for i in sample.points.indices where !covered[i] {
            let dx = sample.points[i].x - point.x
            let dy = sample.points[i].y - point.y
            if dx * dx + dy * dy <= r2 {
                covered[i] = true
                coveredCount += 1
            }
        }
    }
}

// MARK: - Number list  (NumberListActivity)

enum NumberArt {
    /// Index i holds the picture for number i+1 (NumberListAdapter.NUMBER_DRAWABLES).
    static let names: [String] = [
        "one_1", "two_2", "three_3", "four_4", "five_5",
        "six_6", "seven_7", "eight_8", "nine_9", "ten_10",
        "eleven_11", "twelve_12", "thirteen_13", "fourteen_14", "fifteen_15",
        "sixteen_16", "seventeen_17", "eighteen_18", "nineteen_19", "twenty_20"
    ]
}

struct NumberListView: View {
    @Environment(Router.self) private var router

    var body: some View {
        ScreenScaffold(title: "Learn Writing") {
            ScrollView {
                LazyVGrid(columns: KidGrid.columns(minimum: 150), spacing: 14) {
                    ForEach(1...20, id: \.self) { number in
                        Button {
                            SpeechService.shared.speak(String(number))
                            router.push(.traceNumber(start: number))
                        } label: {
                            PictureTile(art: { KidImage(name: NumberArt.names[number - 1]) })
                                .aspectRatio(1, contentMode: .fit)
                        }
                        .buttonStyle(PressableStyle())
                        .accessibilityLabel("Number \(number)")
                    }
                }
                .padding(16)
            }
        }
        .onDisappear { SpeechService.shared.stop() }
    }
}

// MARK: - Trace a number  (TraceNumberActivity)

struct TraceNumberView: View {
    @Environment(Router.self) private var router
    let startNumber: Int

    @State private var number = 1
    @State private var sample: GlyphSample?
    @State private var progress: TraceProgress?
    @State private var strokes: [[CGPoint]] = []      // in glyph image space
    @State private var celebrating = false
    @State private var strokeActive = false
    @State private var advanceTask: Task<Void, Never>?

    private static let range = 1...20

    var body: some View {
        ZStack {
            Theme.pageGradient.ignoresSafeArea()
            VStack(spacing: 14) {
                HStack {
                    CircleIconButton(systemName: "chevron.left", label: "Back") { router.pop() }
                    Spacer()
                    Text("Trace the number")
                        .font(Theme.font(18, relativeTo: .headline))
                        .foregroundStyle(Theme.neutralText)
                    Spacer()
                    Color.clear.frame(width: 42, height: 42)
                }
                .padding(.horizontal, 16).padding(.top, 8)

                Text("\(number)")
                    .font(Theme.font(54, relativeTo: .largeTitle))
                    .foregroundStyle(Theme.titleLetters[number % Theme.titleLetters.count])
                    .contentTransition(.numericText())

                traceArea
                    .padding(.horizontal, 20)

                ProgressView(value: min(progress?.fraction ?? 0, 1))
                    .tint(Theme.correctGreen)
                    .padding(.horizontal, 40)
                    .accessibilityLabel("Tracing progress")

                HStack(spacing: 26) {
                    circleButton("chevron.left", label: "Previous number") { go(number - 1) }
                    Button { resetTrace() } label: {
                        Label("Try again", systemImage: "arrow.counterclockwise")
                            .font(Theme.font(16, relativeTo: .headline))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 22).padding(.vertical, 12)
                            .background(Color(hex: 0xFF7043), in: Capsule())
                    }
                    circleButton("chevron.right", label: "Next number") { go(number + 1) }
                }
                Spacer(minLength: 0)
                BannerAdView()
            }
        }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { if sample == nil { go(startNumber, speak: false) } }
        .onDisappear { advanceTask?.cancel(); SpeechService.shared.stop() }
    }

    // MARK: Trace surface

    private var traceArea: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            ZStack {
                RoundedRectangle(cornerRadius: 30).fill(.white)
                    .shadow(color: .black.opacity(0.1), radius: 6, y: 3)

                if let sample {
                    let scale = side / sample.sideLength
                    // the faint guide digit
                    Image(uiImage: sample.image)
                        .renderingMode(.template)
                        .resizable().scaledToFit()
                        .foregroundStyle(Color.gray.opacity(0.28))
                        .frame(width: side, height: side)

                    // the child's paint, clipped to the digit so it never spills outside
                    Canvas { context, _ in
                        for stroke in strokes where !stroke.isEmpty {
                            var path = Path()
                            path.move(to: scaled(stroke[0], scale))
                            for point in stroke.dropFirst() { path.addLine(to: scaled(point, scale)) }
                            if stroke.count == 1 { path.addLine(to: scaled(stroke[0], scale)) }
                            context.stroke(path, with: .linearGradient(
                                Gradient(colors: [Theme.titleLetters[number % 6], Color(hex: 0xFFB300)]),
                                startPoint: .zero, endPoint: CGPoint(x: side, y: side)),
                                style: StrokeStyle(lineWidth: sample.coverRadius * 2 * scale, lineCap: .round, lineJoin: .round))
                        }
                    }
                    .frame(width: side, height: side)
                    .mask(
                        Image(uiImage: sample.image).resizable().scaledToFit().frame(width: side, height: side)
                    )

                    if celebrating {
                        Text("Great job! 🎉")
                            .font(Theme.font(30, relativeTo: .title))
                            .padding(.horizontal, 22).padding(.vertical, 12)
                            .background(.white, in: Capsule())
                            .overlay(Capsule().stroke(Theme.correctGreen, lineWidth: 3))
                            .transition(.scale.combined(with: .opacity))
                    }
                }
            }
            .frame(width: side, height: side)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        guard let sample, !celebrating else { return }
                        // convert from the square's local space to glyph space
                        let originX = (geo.size.width - side) / 2
                        let originY = (geo.size.height - side) / 2
                        let scale = sample.sideLength / side
                        let p = CGPoint(x: (value.location.x - originX) * scale, y: (value.location.y - originY) * scale)
                        if !strokeActive {
                            strokeActive = true
                            strokes.append([p])
                        } else if !strokes.isEmpty {
                            strokes[strokes.count - 1].append(p)
                        }
                        progress?.touch(p)
                        if progress?.isComplete == true { finishTrace() }
                    }
                    .onEnded { _ in strokeActive = false }
            )
        }
        .aspectRatio(1, contentMode: .fit)
    }

    private func scaled(_ p: CGPoint, _ s: CGFloat) -> CGPoint { CGPoint(x: p.x * s, y: p.y * s) }

    private func circleButton(_ symbol: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 24, weight: .heavy))
                .foregroundStyle(Theme.headerBottom)
                .frame(width: 60, height: 60)
                .background(.white, in: Circle())
                .overlay(Circle().stroke(Theme.sunYellow, lineWidth: 3))
                .shadow(color: .black.opacity(0.12), radius: 4, y: 2)
        }
        .accessibilityLabel(label)
    }

    // MARK: Logic

    /// Wraps within 1...20 exactly like the Android `goTo`.
    private func go(_ requested: Int, speak: Bool = true) {
        advanceTask?.cancel()
        let count = Self.range.count
        number = ((requested - 1 + count) % count) + 1
        celebrating = false
        let glyph = GlyphSampler.make(text: String(number))
        sample = glyph
        progress = TraceProgress(sample: glyph)
        strokes = []
        if speak { SpeechService.shared.speak(String(number)) }
    }

    private func resetTrace() {
        guard let sample else { return }
        progress = TraceProgress(sample: sample)
        strokes = []
        celebrating = false
        advanceTask?.cancel()
    }

    private func finishTrace() {
        guard !celebrating else { return }
        withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) { celebrating = true }
        Haptics.success()
        advanceTask = Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(900))
            guard !Task.isCancelled else { return }
            go(number + 1)
        }
    }
}
