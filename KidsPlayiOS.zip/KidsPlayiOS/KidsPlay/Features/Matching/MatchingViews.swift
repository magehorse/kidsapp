import SwiftUI

// MARK: - Data (pure logic - unit tested)

/// Android `LetterPictureRepository` was not in the zip. It is rebuilt here from the Alphabets category
/// (A for Apple ... Z for Zebra), which is what the game visibly used.
struct LetterPicture: Identifiable, Hashable {
    let letter: String
    let word: String
    let imageName: String
    var id: String { letter }
}

enum LetterPictureRepository {
    static let all: [LetterPicture] = build(from: LearningRepository.shared.category(0)?.items ?? [])

    /// Prefers the dedicated matching artwork (`a_apple`, `b_ball` ...) and falls back to the flash-card picture.
    static func build(from items: [LearningItem], imageExists: (String) -> Bool = { UIImage(named: $0) != nil }) -> [LetterPicture] {
        items.compactMap { item in
            guard let first = item.title.first else { return nil }
            let letter = String(first).uppercased()
            let dedicated = "\(letter.lowercased())_\(item.speak.lowercased().replacingOccurrences(of: " ", with: ""))"
            return LetterPicture(letter: letter, word: item.speak, imageName: imageExists(dedicated) ? dedicated : item.image)
        }
    }

    /// A round: `size` pairs (clamped to 2...all.count).
    static func randomRound(size: Int, from pool: [LetterPicture] = all) -> [LetterPicture] {
        let count = min(max(size, 2), pool.count)
        return Array(pool.shuffled().prefix(count)).sorted { $0.letter < $1.letter }
    }
}

// MARK: - Level list  (PatternLevelListActivity)

struct PatternLevel: Identifiable, Hashable {
    let levelNumber: Int
    let roundSize: Int
    let imageName: String
    var id: Int { levelNumber }

    static let all: [PatternLevel] = [
        PatternLevel(levelNumber: 1, roundSize: 3, imageName: "a_apple"),
        PatternLevel(levelNumber: 2, roundSize: 4, imageName: "b_ball"),
        PatternLevel(levelNumber: 3, roundSize: 5, imageName: "c_cat"),
        PatternLevel(levelNumber: 4, roundSize: 6, imageName: "d_dog"),
        PatternLevel(levelNumber: 5, roundSize: 7, imageName: "e_elephant")
    ]
}

struct PatternLevelListView: View {
    @Environment(Router.self) private var router

    var body: some View {
        ScreenScaffold(title: "Match Pattern") {
            ScrollView {
                LazyVGrid(columns: KidGrid.columns(minimum: 150), spacing: 14) {
                    ForEach(PatternLevel.all) { level in
                        Button { router.push(.matchingGame(roundSize: level.roundSize)) } label: {
                            PictureTile(art: { KidImage(name: level.imageName) })
                                .aspectRatio(1, contentMode: .fit)
                        }
                        .buttonStyle(PressableStyle())
                        .accessibilityLabel("Level \(level.levelNumber), \(level.roundSize) pairs")
                    }
                }
                .padding(16)
            }
        }
    }
}

// MARK: - Game  (MatchingGameActivity + MatchGameView)

private struct ItemFramesKey: PreferenceKey {
    static var defaultValue: [String: CGRect] = [:]
    static func reduce(value: inout [String: CGRect], nextValue: () -> [String: CGRect]) {
        value.merge(nextValue()) { _, new in new }
    }
}

private struct LineShape: Shape {
    var start: CGPoint
    var end: CGPoint

    var animatableData: AnimatablePair<CGFloat, CGFloat> {
        get { AnimatablePair(end.x, end.y) }
        set { end = CGPoint(x: newValue.first, y: newValue.second) }
    }

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: start)
        path.addLine(to: end)
        return path
    }
}

struct MatchingGameView: View {
    @Environment(Router.self) private var router
    let roundSize: Int

    @State private var round: [LetterPicture] = []
    @State private var pictureOrder: [LetterPicture] = []
    @State private var matched: Set<String> = []
    @State private var frames: [String: CGRect] = [:]

    @State private var dragLetter: String?
    @State private var dragEnd: CGPoint = .zero

    @State private var feedback = "Match each letter to its picture"
    @State private var feedbackColor = Theme.neutralText
    @State private var roundsCompleted = 0
    @State private var showCelebration = false
    @State private var nextRoundTask: Task<Void, Never>?

    private let space = "board"

    var body: some View {
        ZStack {
            Theme.pageGradient.ignoresSafeArea()
            VStack(spacing: 10) {
                HStack {
                    CircleIconButton(systemName: "chevron.left", label: "Back") { router.pop() }
                    Spacer()
                    Text("Rounds completed: \(roundsCompleted)")
                        .font(Theme.font(15, relativeTo: .subheadline))
                        .foregroundStyle(Theme.neutralText)
                }
                .padding(.horizontal, 16).padding(.top, 8)

                Text(feedback)
                    .font(Theme.font(18, relativeTo: .headline))
                    .foregroundStyle(feedbackColor)
                    .multilineTextAlignment(.center)
                    .frame(minHeight: 28)

                board
                    .padding(.horizontal, 18)
                    .padding(.bottom, 8)

                BannerAdView()
            }

            if showCelebration {
                Text("All matched! Great job! 🎉")
                    .font(Theme.font(24, relativeTo: .title2))
                    .padding(.horizontal, 24).padding(.vertical, 14)
                    .background(.white, in: Capsule())
                    .overlay(Capsule().stroke(Theme.correctGreen, lineWidth: 3))
                    .shadow(radius: 8)
                    .transition(.scale.combined(with: .opacity))
            }
        }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { if round.isEmpty { startNewRound() } }
        .onDisappear { nextRoundTask?.cancel(); SpeechService.shared.stop() }
    }

    // MARK: Board

    private var board: some View {
        ZStack {
            HStack(alignment: .center) {
                VStack(spacing: 14) {
                    ForEach(round) { item in letterBubble(item) }
                }
                Spacer(minLength: 60)
                VStack(spacing: 14) {
                    ForEach(pictureOrder) { item in pictureCard(item) }
                }
            }
            .frame(maxHeight: .infinity)

            // permanent green lines for solved pairs
            ForEach(Array(matched), id: \.self) { letter in
                if let start = anchor("L-\(letter)", right: true), let end = anchor("R-\(letter)", right: false) {
                    LineShape(start: start, end: end)
                        .stroke(Theme.correctGreen, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                        .allowsHitTesting(false)
                }
            }

            // the line being dragged
            if let letter = dragLetter, let start = anchor("L-\(letter)", right: true) {
                LineShape(start: start, end: dragEnd)
                    .stroke(Theme.sunYellow, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                    .allowsHitTesting(false)
            }
        }
        .coordinateSpace(name: space)
        .onPreferenceChange(ItemFramesKey.self) { frames = $0 }
    }

    private func letterBubble(_ item: LetterPicture) -> some View {
        let isMatched = matched.contains(item.letter)
        return Text(item.letter)
            .font(Theme.font(34, relativeTo: .largeTitle))
            .foregroundStyle(isMatched ? .white : Theme.headerBottom)
            .frame(width: 74, height: 74)
            .background(isMatched ? Theme.correctGreen : .white, in: Circle())
            .overlay(Circle().stroke(isMatched ? Theme.correctGreen : Theme.sunYellow, lineWidth: 4))
            .shadow(color: .black.opacity(0.12), radius: 4, y: 2)
            .background(frameReader("L-\(item.letter)"))
            .gesture(dragGesture(for: item), including: isMatched ? .none : .all)
            .accessibilityLabel("Letter \(item.letter)")
            .accessibilityHint("Drag to the matching picture")
    }

    private func pictureCard(_ item: LetterPicture) -> some View {
        let isMatched = matched.contains(item.letter)
        return KidImage(name: item.imageName)
            .padding(6)
            .frame(width: 90, height: 90)
            .background(.white, in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(isMatched ? Theme.correctGreen : .white, lineWidth: 4))
            .shadow(color: .black.opacity(0.10), radius: 4, y: 2)
            .background(frameReader("R-\(item.letter)"))
            .accessibilityLabel(item.word)
    }

    private func frameReader(_ key: String) -> some View {
        GeometryReader { geo in
            Color.clear.preference(key: ItemFramesKey.self, value: [key: geo.frame(in: .named(space))])
        }
    }

    private func anchor(_ key: String, right: Bool) -> CGPoint? {
        guard let frame = frames[key] else { return nil }
        return CGPoint(x: right ? frame.maxX : frame.minX, y: frame.midY)
    }

    // MARK: Interaction

    private func dragGesture(for item: LetterPicture) -> some Gesture {
        DragGesture(minimumDistance: 0, coordinateSpace: .named(space))
            .onChanged { value in
                dragLetter = item.letter
                dragEnd = value.location
            }
            .onEnded { value in
                drop(item, at: value.location)
            }
    }

    private func drop(_ item: LetterPicture, at point: CGPoint) {
        let target = pictureOrder.first { picture in
            guard let frame = frames["R-\(picture.letter)"] else { return false }
            return frame.insetBy(dx: -10, dy: -10).contains(point)
        }

        guard let target else {
            bounceBack(item)      // dropped on nothing - just retract, no penalty message
            return
        }

        if target.letter == item.letter {
            matched.insert(item.letter)
            dragLetter = nil
            feedback = "Correct! ✅"
            feedbackColor = Theme.correctGreen
            Haptics.success()
            SpeechService.shared.speak(item.word)
            if matched.count == round.count { roundFinished() }
        } else {
            feedback = "Not quite - try again!"
            feedbackColor = Theme.wrongRed
            Haptics.error()
            bounceBack(item)
        }
    }

    /// Wrong drops spring back to the letter; there is no fail state.
    private func bounceBack(_ item: LetterPicture) {
        guard let start = anchor("L-\(item.letter)", right: true) else { dragLetter = nil; return }
        withAnimation(.spring(response: 0.3, dampingFraction: 0.55)) { dragEnd = start }
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(320))
            dragLetter = nil
        }
    }

    private func roundFinished() {
        roundsCompleted += 1
        withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) { showCelebration = true }
        nextRoundTask = Task { @MainActor in
            try? await Task.sleep(for: .seconds(1))
            guard !Task.isCancelled else { return }
            withAnimation { showCelebration = false }
            startNewRound()
        }
    }

    private func startNewRound() {
        feedback = "Match each letter to its picture"
        feedbackColor = Theme.neutralText
        matched = []
        dragLetter = nil
        round = LetterPictureRepository.randomRound(size: roundSize)
        pictureOrder = round.shuffled()
    }
}
