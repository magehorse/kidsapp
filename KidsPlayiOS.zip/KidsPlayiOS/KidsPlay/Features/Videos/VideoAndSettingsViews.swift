import SwiftUI
import WebKit

// MARK: - Video catalog
//
// Android's VideoLearningActivity / ListVideoActivity / VideoPlayActivity (YouTube) were not in the zip,
// so their data source is unknown. This reads a bundled `videos.json` you fill in with YouTube ids:
//
//   { "categories": [ { "title": "ABC Songs", "image": "vt_abc",
//                       "videos": [ { "title": "ABC Song", "youtubeID": "75p-N9YKqNo" } ] } ] }

struct VideoCatalog: Decodable {
    struct Video: Decodable, Identifiable, Hashable {
        let title: String
        let youtubeID: String
        var id: String { youtubeID }
    }
    struct Category: Decodable, Identifiable, Hashable {
        let title: String
        let image: String
        let videos: [Video]
        var id: String { title }
    }

    let categories: [Category]

    static let shared: VideoCatalog = {
        guard let url = Bundle.main.url(forResource: "videos", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let catalog = try? JSONDecoder().decode(VideoCatalog.self, from: data) else {
            return VideoCatalog(categories: [])
        }
        return catalog
    }()
}

struct VideoLearningView: View {
    @Environment(Router.self) private var router

    var body: some View {
        ScreenScaffold(title: "Video Song") {
            let categories = VideoCatalog.shared.categories
            if categories.isEmpty {
                EmptyStateView(symbol: "play.rectangle", message: "No videos yet.\nAdd YouTube ids to videos.json.")
            } else {
                ScrollView {
                    LazyVGrid(columns: KidGrid.columns(minimum: 150), spacing: 14) {
                        ForEach(categories) { category in
                            Button { router.push(.videoList(category: category.title)) } label: {
                                PictureTile(art: { KidImage(name: category.image) }, caption: category.title)
                            }
                            .buttonStyle(PressableStyle())
                        }
                    }
                    .padding(16)
                }
            }
        }
    }
}

struct VideoListView: View {
    let category: String
    @State private var playing: VideoCatalog.Video?

    var body: some View {
        let videos = VideoCatalog.shared.categories.first { $0.title == category }?.videos ?? []
        ScreenScaffold(title: category) {
            if videos.isEmpty {
                EmptyStateView(symbol: "play.rectangle", message: "No videos in this list yet.")
            } else {
                List(videos) { video in
                    Button { playing = video } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "play.circle.fill").font(.system(size: 34)).foregroundStyle(Color(hex: 0xFF7043))
                            Text(video.title).font(Theme.font(17, relativeTo: .headline)).foregroundStyle(Theme.neutralText)
                            Spacer()
                        }
                        .padding(.vertical, 6)
                    }
                    .listRowBackground(Color.white.opacity(0.85))
                }
                .scrollContentBackground(.hidden)
            }
        }
        .fullScreenCover(item: $playing) { video in
            YouTubePlayerScreen(video: video)
        }
    }
}

private struct YouTubePlayerScreen: View {
    let video: VideoCatalog.Video
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.ignoresSafeArea()
            YouTubeWebView(videoID: video.youtubeID)
                .ignoresSafeArea(edges: .bottom)
            CircleIconButton(systemName: "xmark", label: "Close video") { dismiss() }
                .padding(16)
        }
    }
}

/// Uses the official iframe embed. Navigation away from the embed is blocked - a kids app must not
/// let a child wander into YouTube's recommendations or comments.
private struct YouTubeWebView: UIViewRepresentable {
    let videoID: String

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.isScrollEnabled = false

        let html = """
        <html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"></head>
        <body style="margin:0;background:#000;">
        <iframe width="100%" height="100%" style="position:absolute;inset:0;border:0;"
          src="https://www.youtube.com/embed/\(videoID)?playsinline=1&rel=0&modestbranding=1&controls=1&fs=0&iv_load_policy=3&autoplay=1"
          allow="autoplay; encrypted-media" allowfullscreen="false"></iframe>
        </body></html>
        """
        web.loadHTMLString(html, baseURL: URL(string: "https://www.youtube.com"))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        private var didLoadPlayer = false

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            // Frames inside the page (the YouTube iframe itself) may load normally.
            if navigationAction.targetFrame?.isMainFrame == false {
                decisionHandler(.allow)
                return
            }
            // The one and only main-frame load is our own HTML; anything after that (links, redirects) is blocked.
            if !didLoadPlayer, navigationAction.navigationType == .other {
                didLoadPlayer = true
                decisionHandler(.allow)
            } else {
                decisionHandler(.cancel)
            }
        }
    }
}

struct EmptyStateView: View {
    let symbol: String
    let message: String

    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: symbol).font(.system(size: 56)).foregroundStyle(Theme.headerTop.opacity(0.7))
            Text(message)
                .font(Theme.font(16, relativeTo: .body))
                .foregroundStyle(Theme.neutralText)
                .multilineTextAlignment(.center)
        }
        .padding(30)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Settings  (SettingActivity - not in the zip; rebuilt from the prefs the code reads)

struct SettingsView: View {
    @Environment(Router.self) private var router
    @Environment(AppSettings.self) private var settings
    @State private var privacyGate = false
    @State private var nameDraft = ""

    var body: some View {
        @Bindable var settings = settings
        ScreenScaffold(title: "Settings", showBanner: false) {
            Form {
                Section("About you") {
                    TextField("Your name", text: $nameDraft)
                        .textInputAutocapitalization(.words)
                        .submitLabel(.done)
                        .onSubmit { saveName() }
                        .onAppear { nameDraft = settings.userName }
                    Button("Save name") { saveName() }
                        .disabled(nameDraft.trimmingCharacters(in: .whitespaces).isEmpty)
                }

                Section("Sound") {
                    Toggle("Read words out loud", isOn: $settings.soundOn)
                }

                Section("Numbers language") {
                    Picker("Numbers", selection: $settings.language) {
                        Text("English").tag("en")
                        Text("हिन्दी").tag("hi")
                    }
                    .pickerStyle(.segmented)
                }

                Section("Grown-ups") {
                    Button("Privacy Policy") { privacyGate = true }
                }

                Section {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .scrollContentBackground(.hidden)
        }
        .parentalGate(isPresented: $privacyGate) { router.push(.privacyPolicy) }
    }

    private func saveName() {
        let trimmed = nameDraft.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return }
        settings.userName = trimmed
    }
}

// MARK: - Privacy policy  (PrivacyPolicyActivity)

struct PrivacyPolicyView: View {
    var body: some View {
        ScreenScaffold(title: "Privacy Policy", showBanner: false) {
            PolicyWebView(url: AppConfig.privacyPolicyURL)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .padding(.horizontal, 12)
                .padding(.bottom, 8)
        }
    }
}

private struct PolicyWebView: UIViewRepresentable {
    let url: URL

    func makeCoordinator() -> Coordinator { Coordinator(host: url.host) }

    func makeUIView(context: Context) -> WKWebView {
        let web = WKWebView()
        web.navigationDelegate = context.coordinator
        web.load(URLRequest(url: url))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    /// Android loaded every link inside the same WebView. Here links stay in-app but only on the policy's own host.
    final class Coordinator: NSObject, WKNavigationDelegate {
        let host: String?
        init(host: String?) { self.host = host }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if navigationAction.navigationType == .linkActivated, navigationAction.request.url?.host != host {
                decisionHandler(.cancel)
            } else {
                decisionHandler(.allow)
            }
        }
    }
}
