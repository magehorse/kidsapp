import SwiftUI

// MARK: - Category grid  (HomeActivity)

struct CategoryGridView: View {
    @Environment(Router.self) private var router
    /// 1 = learn, 2 = Look & Choose, 3 = Listen & Guess, 5 = Mathematics subset
    let type: Int

    private var title: String {
        switch type {
        case 2: return "Look & Choose!"
        case 3: return "Listen and Guess"
        case 4: return "Video Song"
        case 5: return "Mathematics for Kids"
        default: return "Kids Learning"
        }
    }

    /// Absolute category ids to show (Android used a `positionMap` for the filtered maths grid).
    private var categoryIDs: [Int] {
        type == 5 ? LearningRepository.mathCategoryIDs : Array(LearningRepository.homeTitles.indices)
    }

    var body: some View {
        ScreenScaffold(title: title) {
            ScrollView {
                LazyVGrid(columns: KidGrid.columns(minimum: 150), spacing: 14) {
                    ForEach(categoryIDs, id: \.self) { id in
                        Button { open(id) } label: {
                            PictureTile(art: { KidImage(name: LearningRepository.homeImages[id]) })
                                .aspectRatio(1, contentMode: .fit)
                        }
                        .buttonStyle(PressableStyle())
                        .accessibilityLabel(LearningRepository.homeTitles[id])
                    }
                }
                .padding(16)
            }
        }
    }

    private func open(_ id: Int) {
        let name = LearningRepository.homeTitles[id]
        switch type {
        case 2: router.push(.lookChoose(category: id, title: name))
        case 3: router.push(.listenGuess(category: id, title: name))
        default: router.push(.subCategory(position: id, title: name))   // type 1 and the maths grid (5)
        }
    }
}

// MARK: - Items of one category  (SubActivity)

struct SubCategoryView: View {
    @Environment(Router.self) private var router
    @Environment(AppSettings.self) private var settings
    let categoryID: Int
    let title: String

    var body: some View {
        let items = LearningRepository.shared.items(for: categoryID, language: settings.language)
        ScreenScaffold(title: title) {
            ScrollView {
                LazyVGrid(columns: KidGrid.columns(minimum: 150), spacing: 14) {
                    ForEach(Array(items.enumerated()), id: \.offset) { index, item in
                        Button { router.push(.flashCard(category: categoryID, selected: index)) } label: {
                            PictureTile(art: { KidImage(name: item.image).frame(height: 120) }, caption: captionText(for: item))
                        }
                        .buttonStyle(PressableStyle())
                        .accessibilityLabel(item.title)
                    }
                }
                .padding(16)
            }
        }
    }

    /// Category 0 titles are "A for Apple" - the picture already says it, so keep tiles uncaptioned like Android.
    private func captionText(for item: LearningItem) -> String? {
        categoryID == 0 ? nil : item.title
    }
}

// MARK: - Flash cards  (FullScreenActivity)

struct FlashCardView: View {
    @Environment(Router.self) private var router
    @Environment(AppSettings.self) private var settings
    let categoryID: Int
    let startIndex: Int

    @State private var index: Int
    @State private var titleBounce = false
    @State private var didSetInitial = false

    init(categoryID: Int, startIndex: Int) {
        self.categoryID = categoryID
        self.startIndex = startIndex
        _index = State(initialValue: max(startIndex, 0))   // open on the tapped card, no flash of card 0
    }

    var body: some View {
        let items = LearningRepository.shared.items(for: categoryID, language: settings.language)
        let lastIndex = max(items.count - 1, 0)

        ZStack {
            Theme.pageGradient.ignoresSafeArea()
            VStack(spacing: 0) {
                HStack {
                    CircleIconButton(systemName: "chevron.left", label: "Back") { router.pop() }
                    Spacer()
                    Text("\(min(index + 1, items.count)) / \(items.count)")
                        .font(Theme.font(15, relativeTo: .subheadline))
                        .foregroundStyle(Theme.neutralText)
                }
                .padding(.horizontal, 16).padding(.vertical, 10)

                if items.isEmpty {
                    Spacer()
                    Text("Nothing here yet").font(.title3).foregroundStyle(.secondary)
                    Spacer()
                } else {
                    // Title
                    Text(items[min(index, lastIndex)].title)
                        .font(Theme.font(34, relativeTo: .largeTitle))
                        .foregroundStyle(Theme.titleLetters[index % Theme.titleLetters.count])
                        .multilineTextAlignment(.center)
                        .minimumScaleFactor(0.5)
                        .lineLimit(2)
                        .padding(.horizontal, 20)
                        .scaleEffect(titleBounce ? 1.0 : 0.8)
                        .id("title-\(index)")
                        .accessibilityAddTraits(.isHeader)

                    // Pager (swipe or use the arrows - Android used a non-swipeable pager + arrows)
                    TabView(selection: $index) {
                        ForEach(Array(items.enumerated()), id: \.offset) { i, item in
                            FlashCardImage(name: item.image, isCurrent: i == index)
                                .tag(i)
                        }
                    }
                    .tabViewStyle(.page(indexDisplayMode: .never))

                    HStack(spacing: 40) {
                        arrow("chevron.left", label: "Previous", enabled: index > 0) { index -= 1 }
                        Button { speakCurrent(items) } label: {
                            Image(systemName: "speaker.wave.3.fill")
                                .font(.system(size: 26, weight: .bold))
                                .foregroundStyle(.white)
                                .frame(width: 70, height: 70)
                                .background(Theme.primaryBlue, in: Circle())
                        }
                        .accessibilityLabel("Say it again")
                        arrow("chevron.right", label: "Next", enabled: index < lastIndex) { index += 1 }
                    }
                    .padding(.vertical, 18)
                }
                BannerAdView()
            }
        }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .onAppear {
            guard !didSetInitial else { return }
            didSetInitial = true
            let target = min(max(startIndex, 0), lastIndex)
            if target != index {
                index = target          // onChange(of: index) will announce
            } else {
                announce(items)
            }
        }
        .onChange(of: index) { _, _ in announce(items) }
        .onDisappear { SpeechService.shared.stop() }
    }

    private func arrow(_ symbol: String, label: String, enabled: Bool, action: @escaping () -> Void) -> some View {
        Button {
            withAnimation(.easeInOut) { action() }
        } label: {
            Image(systemName: symbol)
                .font(.system(size: 26, weight: .heavy))
                .foregroundStyle(enabled ? Theme.headerBottom : .gray.opacity(0.5))
                .frame(width: 64, height: 64)
                .background(.white, in: Circle())
                .overlay(Circle().stroke(Theme.sunYellow, lineWidth: 3))
                .shadow(color: .black.opacity(0.12), radius: 4, y: 2)
        }
        .disabled(!enabled)
        .accessibilityLabel(label)
    }

    private func announce(_ items: [LearningItem]) {
        guard items.indices.contains(index) else { return }
        titleBounce = false
        withAnimation(.spring(response: 0.5, dampingFraction: 0.45)) { titleBounce = true }
        SpeechService.shared.speak(items[index].speak)
    }

    private func speakCurrent(_ items: [LearningItem]) {
        guard items.indices.contains(index) else { return }
        SpeechService.shared.speak(items[index].speak, force: true)
    }
}

private struct FlashCardImage: View {
    let name: String
    let isCurrent: Bool
    @State private var tada = false

    var body: some View {
        KidImage(name: name)
            .padding(28)
            .rotationEffect(.degrees(tada ? 0 : -4))
            .scaleEffect(tada ? 1 : 0.9)
            .onChange(of: isCurrent) { _, nowCurrent in
                guard nowCurrent else { return }
                tada = false
                withAnimation(.spring(response: 0.5, dampingFraction: 0.4)) { tada = true }
            }
            .onAppear {
                withAnimation(.spring(response: 0.5, dampingFraction: 0.4)) { tada = true }
            }
    }
}

// MARK: - Maths World  (GameMenuActivity - not in the zip)

/// The Android `GameMenuActivity` / `GameActivity` / `ResultsActivity` were not included in the upload.
/// Until they are ported, the Mathematics tile opens the maths category grid that Android also
/// had (HomeActivity type 5): Numbers, Shapes, Geometry, Month.
struct MathsWorldView: View {
    var body: some View {
        CategoryGridView(type: 5)
    }
}
