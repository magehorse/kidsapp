import SwiftUI
import UIKit
import ImageIO

// MARK: - Catalog
//
// Android's CommonUtilities.getSmallEasyBGImageList / getSmallHardBGImageList read colouring pictures from the
// module's `assets/` folder, which was not in the zip. iOS reads them from a folder reference in the bundle:
//
//   KidsPlay/Resources/Drawings/easy/*.png   (or .jpg / .webp-converted-to-png)
//   KidsPlay/Resources/Drawings/hard/*.png
//
// tools/import_android_assets.py copies them across for you.

struct DrawingPicture: Identifiable, Hashable {
    let easy: Bool
    let index: Int
    let url: URL
    var id: String { "\(easy ? "easy" : "hard")-\(index)" }
}

enum DrawingCatalog {
    private static let allowed: Set<String> = ["png", "jpg", "jpeg"]
    nonisolated(unsafe) private static var cache: [Bool: [DrawingPicture]] = [:]

    static func pictures(easy: Bool, bundle: Bundle = .main) -> [DrawingPicture] {
        if let cached = cache[easy] { return cached }
        let folder = bundle.resourceURL?.appendingPathComponent("Drawings").appendingPathComponent(easy ? "easy" : "hard")
        let files = (try? FileManager.default.contentsOfDirectory(at: folder ?? URL(fileURLWithPath: "/nonexistent"),
                                                                  includingPropertiesForKeys: nil)) ?? []
        let sorted = files
            .filter { allowed.contains($0.pathExtension.lowercased()) }
            .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
        let result = sorted.enumerated().map { DrawingPicture(easy: easy, index: $0.offset, url: $0.element) }
        cache[easy] = result
        return result
    }

    static func picture(easy: Bool, index: Int) -> DrawingPicture? {
        let list = pictures(easy: easy)
        return list.indices.contains(index) ? list[index] : nil
    }
}

// MARK: - Image loading (downsampled so 60 large colouring pages never blow memory - Android had `largeHeap` for this)

enum ImageLoader {
    static func downsampled(url: URL, maxPixel: CGFloat) -> UIImage? {
        let options: [CFString: Any] = [kCGImageSourceShouldCache: false]
        guard let source = CGImageSourceCreateWithURL(url as CFURL, options as CFDictionary) else { return nil }
        let thumbOptions: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixel
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(source, 0, thumbOptions as CFDictionary) else { return nil }
        return UIImage(cgImage: cg)
    }
}

struct DrawingThumbnail: View {
    let picture: DrawingPicture
    @State private var image: UIImage?

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image).resizable().scaledToFit()
            } else {
                Color.gray.opacity(0.08).overlay(ProgressView())
            }
        }
        .task(id: picture.id) {
            let url = picture.url
            image = await Task.detached(priority: .utility) { ImageLoader.downsampled(url: url, maxPixel: 420) }.value
        }
    }
}

// MARK: - Picker  (BGImageListActivity)

struct DrawPickerView: View {
    @Environment(Router.self) private var router
    @State private var easy = true

    var body: some View {
        VStack(spacing: 0) {
            header
            let pictures = DrawingCatalog.pictures(easy: easy)
            if pictures.isEmpty {
                EmptyStateView(symbol: "paintbrush.pointed",
                               message: "No pictures found.\nRun tools/import_android_assets.py to add the colouring pages.")
            } else {
                ScrollView {
                    LazyVGrid(columns: KidGrid.columns(minimum: 150), spacing: 14) {
                        ForEach(pictures) { picture in
                            Button { router.push(.drawEditor(easy: picture.easy, index: picture.index)) } label: {
                                PictureTile(art: { DrawingThumbnail(picture: picture).frame(height: 150) })
                            }
                            .buttonStyle(PressableStyle())
                            .accessibilityLabel("Picture \(picture.index + 1)")
                        }
                    }
                    .padding(16)
                }
            }
            BannerAdView()
        }
        .background(Theme.pageGradient.ignoresSafeArea())
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
    }

    private var header: some View {
        VStack(spacing: 12) {
            HStack {
                CircleIconButton(systemName: "chevron.left", label: "Back") { router.pop() }
                Spacer()
                Text("Choose a Picture").font(Theme.font(20, relativeTo: .title3)).foregroundStyle(.white)
                Spacer()
                Color.clear.frame(width: 42, height: 42)
            }
            HStack(spacing: 10) {
                tab("Easy", selected: easy) { easy = true }
                tab("Hard", selected: !easy) { easy = false }
            }
        }
        .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 14)
        .frame(maxWidth: .infinity)
        .background(Theme.matchHeader.ignoresSafeArea(edges: .top))
    }

    private func tab(_ title: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(Theme.font(16, relativeTo: .headline))
                .foregroundStyle(selected ? .white : Theme.matchHeader)
                .frame(maxWidth: .infinity).padding(.vertical, 10)
                .background(selected ? Theme.sunYellow.opacity(0.0) : Color.white, in: Capsule())
                .background(selected ? Color(hex: 0xFF7043) : .clear, in: Capsule())
        }
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}
