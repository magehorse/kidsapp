import SwiftUI
import UIKit

// MARK: - Model

enum DrawTool: String, CaseIterable, Identifiable {
    case brush, pencil, magic, sticker, text
    var id: String { rawValue }

    var title: String {
        switch self {
        case .brush: return "Brush"
        case .pencil: return "Pencil"
        case .magic: return "Magic"
        case .sticker: return "Sticker"
        case .text: return "Text"
        }
    }

    var symbol: String {
        switch self {
        case .brush: return "paintbrush.fill"
        case .pencil: return "pencil"
        case .magic: return "sparkles"
        case .sticker: return "face.smiling.fill"
        case .text: return "textformat"
        }
    }

    var drawsOnCanvas: Bool { self == .brush || self == .pencil || self == .magic }
}

struct StrokeItem: Identifiable {
    enum Kind: Equatable { case paint, erase, stamp(String) }

    let id = UUID()
    var points: [CGPoint]
    var color: Color
    var width: CGFloat
    var blur: CGFloat
    var kind: Kind
}

struct ItemTransform: Equatable {
    var center: CGPoint
    var scale: CGFloat = 1
    var rotation: Angle = .zero
}

struct StickerItem: Identifiable {
    let id = UUID()
    var symbol: String
    var transform: ItemTransform
}

enum TextFace: String, CaseIterable, Identifiable {
    case bubble = "Bubble", rounded = "Rounded", serif = "Serif", mono = "Mono"
    var id: String { rawValue }

    func font(size: CGFloat) -> Font {
        switch self {
        case .bubble: return .custom("Poppins-Bold", size: size)
        case .rounded: return .system(size: size, weight: .heavy, design: .rounded)
        case .serif: return .system(size: size, weight: .bold, design: .serif)
        case .mono: return .system(size: size, weight: .bold, design: .monospaced)
        }
    }
}

struct TextItem: Identifiable {
    let id = UUID()
    var text: String
    var color: Color
    var face: TextFace
    var transform: ItemTransform
}

@MainActor
@Observable
final class DrawingModel {
    static let magicStamps = ["⭐️", "❤️", "🌸", "🦋", "🌈", "🐾", "☁️", "🍀"]
    static let stickers = ["😀", "😍", "🥳", "🐶", "🐱", "🦁", "🐼", "🦄", "🌞", "🌙", "⭐️", "❤️",
                           "🌈", "🎈", "🎁", "🚗", "🚀", "🍎", "🍓", "🍦", "⚽️", "🎨", "🦋", "🌻"]

    var tool: DrawTool = .brush
    var erasing = false

    var brushColor: Color = DrawingPalette.paintBrush[5]
    var pencilColor: Color = DrawingPalette.pencil[0]
    var brushSize: CGFloat = 18
    var pencilSize: CGFloat = 4
    /// 0 = crisp ... 1 = very soft (Android `sbSmoothness`)
    var smoothness: CGFloat = 0
    var magicStamp = magicStamps[0]

    private(set) var strokes: [StrokeItem] = []
    private(set) var redoStack: [StrokeItem] = []
    var stickers: [StickerItem] = []
    var texts: [TextItem] = []
    var selectedID: UUID?
    private(set) var isDirty = false

    var hasContent: Bool { !strokes.isEmpty || !stickers.isEmpty || !texts.isEmpty }
    var canUndo: Bool { !strokes.isEmpty }
    var canRedo: Bool { !redoStack.isEmpty }

    private var stampSpacing: CGFloat { max(brushSize * 2.2, 34) }

    // MARK: Stroke lifecycle

    func beginStroke(at point: CGPoint) {
        selectedID = nil
        redoStack.removeAll()
        isDirty = true
        switch tool {
        case .brush:
            strokes.append(StrokeItem(points: [point], color: brushColor, width: brushSize,
                                      blur: smoothness * 12, kind: erasing ? .erase : .paint))
        case .pencil:
            strokes.append(StrokeItem(points: [point], color: pencilColor, width: pencilSize,
                                      blur: 0, kind: erasing ? .erase : .paint))
        case .magic:
            strokes.append(StrokeItem(points: [point], color: .clear, width: brushSize * 2.2,
                                      blur: 0, kind: .stamp(magicStamp)))
        default: break
        }
    }

    func extendStroke(to point: CGPoint) {
        guard var last = strokes.last else { return }
        if case .stamp = last.kind {
            // one stamp every `stampSpacing` points along the path
            if let previous = last.points.last, hypot(point.x - previous.x, point.y - previous.y) < stampSpacing { return }
        }
        last.points.append(point)
        strokes[strokes.count - 1] = last
    }

    func undo() {
        guard let last = strokes.popLast() else { return }
        redoStack.append(last)
    }

    func redo() {
        guard let stroke = redoStack.popLast() else { return }
        strokes.append(stroke)
    }

    /// Android "clear" for the magic brush: removes only the stamp strokes.
    func clearMagic() {
        strokes.removeAll { if case .stamp = $0.kind { return true } else { return false } }
        redoStack.removeAll()
    }

    // MARK: Items

    func addSticker(_ symbol: String, at center: CGPoint) {
        isDirty = true
        let item = StickerItem(symbol: symbol, transform: ItemTransform(center: center))
        stickers.append(item)
        selectedID = item.id
    }

    func addText(_ text: String, color: Color, face: TextFace, at center: CGPoint) {
        isDirty = true
        let item = TextItem(text: text, color: color, face: face, transform: ItemTransform(center: center))
        texts.append(item)
        selectedID = item.id
    }

    func delete(_ id: UUID) {
        stickers.removeAll { $0.id == id }
        texts.removeAll { $0.id == id }
        if selectedID == id { selectedID = nil }
    }

    func markSaved() { isDirty = false }
    func markDirty() { isDirty = true }
}

// MARK: - Painting

enum StrokePath {
    /// Smooth quad-curve path through the points.
    static func path(for points: [CGPoint]) -> Path {
        var path = Path()
        guard let first = points.first else { return path }
        path.move(to: first)
        guard points.count > 1 else { return path }
        for i in 1..<points.count {
            let mid = CGPoint(x: (points[i - 1].x + points[i].x) / 2, y: (points[i - 1].y + points[i].y) / 2)
            path.addQuadCurve(to: mid, control: points[i - 1])
        }
        if let last = points.last { path.addLine(to: last) }
        return path
    }
}

private struct PaintCanvas: View {
    let strokes: [StrokeItem]

    var body: some View {
        Canvas { context, _ in
            context.drawLayer { layer in
                for stroke in strokes { draw(stroke, in: &layer) }
            }
        }
        .allowsHitTesting(false)
    }

    private func draw(_ stroke: StrokeItem, in layer: inout GraphicsContext) {
        switch stroke.kind {
        case .stamp(let symbol):
            let text = layer.resolve(Text(symbol).font(.system(size: stroke.width)))
            for point in stroke.points { layer.draw(text, at: point, anchor: .center) }

        case .paint, .erase:
            let erasing = stroke.kind == .erase
            let style = StrokeStyle(lineWidth: stroke.width, lineCap: .round, lineJoin: .round)
            layer.drawLayer { inner in
                if erasing { inner.blendMode = .clear }
                if stroke.blur > 0.5, !erasing { inner.addFilter(.blur(radius: stroke.blur)) }
                if stroke.points.count == 1, let point = stroke.points.first {
                    let rect = CGRect(x: point.x - stroke.width / 2, y: point.y - stroke.width / 2,
                                      width: stroke.width, height: stroke.width)
                    inner.fill(Path(ellipseIn: rect), with: .color(erasing ? .black : stroke.color))
                } else {
                    inner.stroke(StrokePath.path(for: stroke.points), with: .color(erasing ? .black : stroke.color), style: style)
                }
            }
        }
    }
}

// MARK: - Item views

private struct ItemBody: View {
    enum Content { case sticker(StickerItem), text(TextItem) }
    let content: Content

    var body: some View {
        switch content {
        case .sticker(let item):
            Text(item.symbol).font(.system(size: 72))
        case .text(let item):
            Text(item.text)
                .font(item.face.font(size: 40))
                .foregroundStyle(item.color)
                .multilineTextAlignment(.center)
                .fixedSize()
        }
    }
}

private extension ItemTransform {
    static func clampedScale(_ value: CGFloat) -> CGFloat { min(max(value, 0.3), 5) }
}

private struct TransformableItem: View {
    @Binding var transform: ItemTransform
    let isSelected: Bool
    let onSelect: () -> Void
    let onDelete: () -> Void
    let content: ItemBody.Content

    @State private var drag: CGSize = .zero
    @State private var pinch: CGFloat = 1
    @State private var twist: Angle = .zero

    var body: some View {
        ItemBody(content: content)
            .padding(10)
            .overlay {
                if isSelected {
                    RoundedRectangle(cornerRadius: 8)
                        .strokeBorder(Theme.primaryBlue, style: StrokeStyle(lineWidth: 2, dash: [6]))
                }
            }
            .overlay(alignment: .topLeading) {
                if isSelected {
                    Button(action: onDelete) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 24))
                            .foregroundStyle(.white, Theme.wrongRed)
                    }
                    .offset(x: -14, y: -14)
                    .accessibilityLabel("Delete")
                }
            }
            .scaleEffect(ItemTransform.clampedScale(transform.scale * pinch))
            .rotationEffect(transform.rotation + twist)
            .position(x: transform.center.x + drag.width, y: transform.center.y + drag.height)
            .gesture(
                DragGesture()
                    .onChanged { drag = $0.translation; onSelect() }
                    .onEnded {
                        transform.center.x += $0.translation.width
                        transform.center.y += $0.translation.height
                        drag = .zero
                    }
            )
            .simultaneousGesture(
                MagnifyGesture()
                    .onChanged { pinch = $0.magnification; onSelect() }
                    .onEnded {
                        transform.scale = ItemTransform.clampedScale(transform.scale * $0.magnification)
                        pinch = 1
                    }
            )
            .simultaneousGesture(
                RotateGesture()
                    .onChanged { twist = $0.rotation; onSelect() }
                    .onEnded { transform.rotation += $0.rotation; twist = .zero }
            )
    }
}

/// Non-interactive rendering of one item - used for the exported image.
private struct StaticItem: View {
    let transform: ItemTransform
    let content: ItemBody.Content

    var body: some View {
        ItemBody(content: content)
            .padding(10)
            .scaleEffect(ItemTransform.clampedScale(transform.scale))
            .rotationEffect(transform.rotation)
            .position(transform.center)
    }
}

// MARK: - Board (what gets exported)

private struct BoardContent: View {
    let model: DrawingModel
    let image: UIImage
    let size: CGSize
    let includeItems: Bool

    var body: some View {
        ZStack {
            Color.white
            PaintCanvas(strokes: model.strokes)
            // The outline sits ON TOP of the paint (multiply), like Android's `ivBackground.bringToFront()`.
            Image(uiImage: image)
                .resizable()
                .frame(width: size.width, height: size.height)
                .blendMode(.multiply)
            if includeItems {
                ForEach(model.stickers) { StaticItem(transform: $0.transform, content: .sticker($0)) }
                ForEach(model.texts) { StaticItem(transform: $0.transform, content: .text($0)) }
            }
        }
        .frame(width: size.width, height: size.height)
        .clipped()
    }
}

// MARK: - Screen  (EditorActivity)

struct DrawingEditorView: View {
    @Environment(Router.self) private var router
    let isEasy: Bool
    let index: Int

    @State private var model = DrawingModel()
    @State private var image: UIImage?
    @State private var boardSize: CGSize = .zero
    @State private var strokeActive = false
    @State private var message: String?
    @State private var isSaving = false
    @State private var askLeave = false
    @State private var showTextDialog = false
    @State private var textDraft = "Text Here"
    @State private var textColor: Color = .black
    @State private var textFace: TextFace = .bubble

    var body: some View {
        VStack(spacing: 0) {
            topBar
            boardArea
            optionsPanel
            toolBar
            BannerAdView()
        }
        .background(Theme.pageGradient.ignoresSafeArea())
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .toast($message)
        .task { await loadImage() }
        .alert("Leave without saving?", isPresented: $askLeave) {
            Button("Keep drawing", role: .cancel) {}
            Button("Leave", role: .destructive) { router.pop() }
        } message: {
            Text("Your picture has not been saved yet.")
        }
        .alert("Add text", isPresented: $showTextDialog) {
            TextField("Text Here", text: $textDraft)
            Button("Cancel", role: .cancel) {}
            Button("Add") { commitText() }
        }
    }

    // MARK: Top bar

    private var topBar: some View {
        HStack(spacing: 10) {
            CircleIconButton(systemName: "chevron.left", label: "Back") {
                if model.isDirty { askLeave = true } else { router.pop() }
            }
            Spacer()
            CircleIconButton(systemName: "arrow.uturn.backward", label: "Undo", tint: model.canUndo ? Theme.headerBottom : .gray.opacity(0.5)) { model.undo() }
                .disabled(!model.canUndo)
            CircleIconButton(systemName: "arrow.uturn.forward", label: "Redo", tint: model.canRedo ? Theme.headerBottom : .gray.opacity(0.5)) { model.redo() }
                .disabled(!model.canRedo)
            Button { Task { await save() } } label: {
                HStack(spacing: 6) {
                    if isSaving { ProgressView().tint(.white) } else { Image(systemName: "square.and.arrow.down.fill") }
                    Text("Save")
                }
                .font(Theme.font(15, relativeTo: .headline))
                .foregroundStyle(.white)
                .padding(.horizontal, 16).padding(.vertical, 10)
                .background(Theme.correctGreen, in: Capsule())
            }
            .disabled(isSaving || image == nil)
        }
        .padding(.horizontal, 14).padding(.vertical, 8)
    }

    // MARK: Board

    private var boardArea: some View {
        GeometryReader { geo in
            ZStack {
                if let image {
                    let size = fitted(image.size, in: CGSize(width: geo.size.width - 24, height: geo.size.height - 12))
                    ZStack {
                        BoardContent(model: model, image: image, size: size, includeItems: false)

                        // catches touches for drawing tools; sits under the items
                        Color.clear
                            .contentShape(Rectangle())
                            .gesture(drawGesture, including: model.tool.drawsOnCanvas ? .all : .none)
                            .onTapGesture { model.selectedID = nil }

                        // Items are interactive only while a sticker/text tool is active, so a child
                        // painting over a sticker never drags it by accident.
                        Group {
                            ForEach($model.stickers) { $sticker in
                                TransformableItem(transform: $sticker.transform, isSelected: model.selectedID == sticker.id,
                                                  onSelect: { model.selectedID = sticker.id; model.markDirty() },
                                                  onDelete: { model.delete(sticker.id) }, content: .sticker(sticker))
                            }
                            ForEach($model.texts) { $text in
                                TransformableItem(transform: $text.transform, isSelected: model.selectedID == text.id,
                                                  onSelect: { model.selectedID = text.id; model.markDirty() },
                                                  onDelete: { model.delete(text.id) }, content: .text(text))
                            }
                        }
                        .allowsHitTesting(model.tool == .sticker || model.tool == .text)
                    }
                    .frame(width: size.width, height: size.height)
                    .clipped()
                    .overlay(Rectangle().stroke(Color.black.opacity(0.08), lineWidth: 1))
                    .shadow(color: .black.opacity(0.12), radius: 6, y: 3)
                    .onAppear { boardSize = size }
                    .onChange(of: size) { _, newSize in boardSize = newSize }
                } else {
                    ProgressView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    private func fitted(_ source: CGSize, in available: CGSize) -> CGSize {
        guard source.width > 0, source.height > 0, available.width > 0, available.height > 0 else { return .zero }
        let scale = min(available.width / source.width, available.height / source.height)
        return CGSize(width: (source.width * scale).rounded(), height: (source.height * scale).rounded())
    }

    private var drawGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { value in
                if !strokeActive {
                    strokeActive = true
                    model.beginStroke(at: value.location)
                } else {
                    model.extendStroke(to: value.location)
                }
            }
            .onEnded { _ in strokeActive = false }
    }

    // MARK: Options

    @ViewBuilder
    private var optionsPanel: some View {
        VStack(spacing: 8) {
            switch model.tool {
            case .brush:
                colorStrip(DrawingPalette.paintBrush, selected: $model.brushColor)
                sliderRow("Size", value: $model.brushSize, range: 6...60, trailing: eraserToggle)
                sliderRow("Soft", value: $model.smoothness, range: 0...1, trailing: EmptyView())
            case .pencil:
                colorStrip(DrawingPalette.pencil, selected: $model.pencilColor)
                sliderRow("Size", value: $model.pencilSize, range: 2...14, trailing: eraserToggle)
            case .magic:
                stampStrip
                HStack {
                    sliderRow("Size", value: $model.brushSize, range: 10...50, trailing: EmptyView())
                    Button("Clear") { model.clearMagic() }
                        .font(Theme.font(14, relativeTo: .subheadline))
                        .buttonStyle(.borderedProminent).tint(Color(hex: 0xFF7043))
                }
            case .sticker:
                stickerStrip
            case .text:
                textOptions
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 8)
        .background(.white.opacity(0.75))
        .animation(.easeInOut(duration: 0.2), value: model.tool)
    }

    private var eraserToggle: some View {
        Toggle(isOn: $model.erasing) {
            Image(systemName: "eraser.fill")
        }
        .toggleStyle(.button)
        .tint(Color(hex: 0xFF7043))
        .accessibilityLabel("Eraser")
    }

    private func sliderRow<Trailing: View>(_ title: String, value: Binding<CGFloat>, range: ClosedRange<CGFloat>, trailing: Trailing) -> some View {
        HStack(spacing: 10) {
            Text(title).font(Theme.font(13, relativeTo: .caption)).foregroundStyle(Theme.neutralText).frame(width: 38, alignment: .leading)
            Slider(value: value, in: range).tint(Theme.primaryBlue)
            trailing
        }
    }

    private func colorStrip(_ colors: [Color], selected: Binding<Color>) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(spacing: 8) {
                ForEach(Array(colors.enumerated()), id: \.offset) { _, color in
                    Button {
                        selected.wrappedValue = color
                        model.erasing = false
                    } label: {
                        Circle().fill(color).frame(width: 34, height: 34)
                            .overlay(Circle().stroke(.white, lineWidth: 2))
                            .overlay(Circle().stroke(selected.wrappedValue == color && !model.erasing ? Color.black : .clear, lineWidth: 2).padding(-3))
                            .shadow(color: .black.opacity(0.2), radius: 2, y: 1)
                    }
                    .accessibilityLabel("Colour")
                }
            }
            .padding(.vertical, 4)
        }
        .frame(height: 44)
    }

    private var stampStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(DrawingModel.magicStamps, id: \.self) { stamp in
                    Button { model.magicStamp = stamp } label: {
                        Text(stamp).font(.system(size: 30))
                            .frame(width: 46, height: 46)
                            .background(model.magicStamp == stamp ? Theme.sunYellow.opacity(0.5) : .white, in: RoundedRectangle(cornerRadius: 12))
                    }
                }
            }
        }
        .frame(height: 50)
    }

    private var stickerStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(DrawingModel.stickers, id: \.self) { symbol in
                    Button {
                        model.addSticker(symbol, at: CGPoint(x: boardSize.width / 2, y: boardSize.height / 2))
                        Haptics.tap()
                    } label: {
                        Text(symbol).font(.system(size: 32))
                            .frame(width: 50, height: 50)
                            .background(.white, in: RoundedRectangle(cornerRadius: 12))
                    }
                    .accessibilityLabel("Add sticker \(symbol)")
                }
            }
        }
        .frame(height: 54)
    }

    private var textOptions: some View {
        HStack(spacing: 12) {
            Button {
                textDraft = "Text Here"
                showTextDialog = true
            } label: {
                Label("Add text", systemImage: "plus")
                    .font(Theme.font(14, relativeTo: .subheadline))
            }
            .buttonStyle(.borderedProminent).tint(Theme.primaryBlue)

            ColorPicker("Colour", selection: $textColor, supportsOpacity: false)
                .labelsHidden()

            Picker("Font", selection: $textFace) {
                ForEach(TextFace.allCases) { Text($0.rawValue).tag($0) }
            }
            .pickerStyle(.menu)
            Spacer()
        }
        .frame(height: 44)
    }

    // MARK: Tool bar

    private var toolBar: some View {
        HStack(spacing: 0) {
            ForEach(DrawTool.allCases) { tool in
                Button {
                    model.tool = tool
                    model.selectedID = nil
                    if tool == .text && model.texts.isEmpty { textDraft = "Text Here"; showTextDialog = true }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: tool.symbol).font(.system(size: 22, weight: .bold))
                        Text(tool.title).font(Theme.font(11, relativeTo: .caption2))
                    }
                    .foregroundStyle(model.tool == tool ? .white : Theme.headerBottom)
                    .frame(maxWidth: .infinity).padding(.vertical, 8)
                    .background(model.tool == tool ? Theme.headerBottom : .clear, in: RoundedRectangle(cornerRadius: 14))
                }
                .accessibilityAddTraits(model.tool == tool ? .isSelected : [])
            }
        }
        .padding(8)
        .background(.white)
    }

    // MARK: Actions

    private func loadImage() async {
        guard image == nil, let picture = DrawingCatalog.picture(easy: isEasy, index: index) else { return }
        let url = picture.url
        image = await Task.detached(priority: .userInitiated) { ImageLoader.downsampled(url: url, maxPixel: 2048) }.value
        if image == nil { message = "Could not load this picture" }
    }

    private func commitText() {
        let trimmed = textDraft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { message = "Please enter text"; return }
        model.addText(trimmed, color: textColor, face: textFace,
                      at: CGPoint(x: boardSize.width / 2, y: boardSize.height / 2))
    }

    private func save() async {
        guard let image, boardSize.width > 0 else { return }
        guard model.hasContent else { message = "Please select at least one item"; return }
        model.selectedID = nil
        isSaving = true
        defer { isSaving = false }

        let renderer = ImageRenderer(content: BoardContent(model: model, image: image, size: boardSize, includeItems: true))
        renderer.scale = min(3, max(1, 2048 / boardSize.width))
        renderer.isOpaque = true
        guard let output = renderer.uiImage else { message = "Save failed"; return }

        do {
            try await PhotoLibrary.save(image: output)
            model.markSaved()
            Haptics.success()
            message = "Saved to your Photos"
        } catch {
            message = (error as? LocalizedError)?.errorDescription ?? "Save failed"
        }
    }
}
