Colouring pages live here: easy/*.png and hard/*.png.
Run tools/import_android_assets.py to copy them from the Android project.
