import SwiftUI

// MARK: - Images

/// Shows an asset-catalog image by name. If the asset has not been imported yet (see tools/import_android_assets.py)
/// it draws a friendly placeholder instead of an empty hole, so the app is usable while you migrate artwork.
struct KidImage: View {
    let name: String
    var contentMode: ContentMode = .fit

    var body: some View {
        if UIImage(named: name) != nil {
            Image(name)
                .resizable()
                .aspectRatio(contentMode: contentMode)
        } else {
            PlaceholderArt(name: name)
        }
    }
}

struct PlaceholderArt: View {
    let name: String

    private var letter: String {
        let cleaned = name.replacingOccurrences(of: "home_", with: "").replacingOccurrences(of: "_", with: " ")
        return String(cleaned.first.map { String($0).uppercased() } ?? "?")
    }

    private var tint: Color {
        // Stable across launches (String.hashValue is randomised per process).
        let sum = name.unicodeScalars.reduce(0) { $0 &+ Int($1.value) }
        return Theme.sectionAccents[sum % Theme.sectionAccents.count]
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(tint.opacity(0.22))
            Text(letter)
                .font(Theme.font(44, relativeTo: .largeTitle))
                .foregroundStyle(tint)
        }
        .aspectRatio(1, contentMode: .fit)
        .accessibilityHidden(true)
    }
}

// MARK: - Screen scaffold (page gradient + colourful title + back button + banner)

struct ScreenScaffold<Content: View>: View {
    @Environment(Router.self) private var router
    let title: String
    var showBanner = true
    @ViewBuilder var content: () -> Content

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                CircleIconButton(systemName: "chevron.left", label: "Back") { router.pop() }
                ColorfulTitle(text: title, size: 24)
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)

            content()
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            if showBanner { BannerAdView() }
        }
        .background(Theme.pageGradient.ignoresSafeArea())
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
    }
}

struct CircleIconButton: View {
    let systemName: String
    let label: String
    var tint: Color = Theme.headerBottom
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(tint)
                .frame(width: 42, height: 42)
                .background(.white, in: Circle())
                .overlay(Circle().stroke(Theme.sunYellow, lineWidth: 2))
                .shadow(color: .black.opacity(0.12), radius: 3, y: 2)
        }
        .accessibilityLabel(label)
    }
}

// MARK: - Title

/// `Utils.setColorfulTitle` - every letter a different colour.
struct ColorfulTitle: View {
    let text: String
    var size: CGFloat = 26

    var body: some View {
        colored
            .font(Theme.font(size, relativeTo: .title))
            .accessibilityLabel(text)
    }

    private var colored: Text {
        var result = Text("")
        for (index, character) in text.enumerated() {
            let color = Theme.titleLetters[index % Theme.titleLetters.count]
            result = result + Text(String(character)).foregroundStyle(color)
        }
        return result
    }
}

// MARK: - Picture tile with the "bubble" pop-in animation (R.anim.bubble_anim)

struct PictureTile<Art: View>: View {
    @ViewBuilder var art: () -> Art
    var caption: String?
    var corner: CGFloat = 22

    @State private var appeared = false

    var body: some View {
        VStack(spacing: 6) {
            art()
                .padding(8)
            if let caption, !caption.isEmpty {
                Text(caption)
                    .font(Theme.font(14, relativeTo: .subheadline))
                    .foregroundStyle(Theme.neutralText)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                    .padding(.horizontal, 6)
                    .padding(.bottom, 8)
            }
        }
        .frame(maxWidth: .infinity)
        .background(.white, in: RoundedRectangle(cornerRadius: corner, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: corner, style: .continuous).stroke(.white, lineWidth: 3))
        .shadow(color: .black.opacity(0.10), radius: 5, y: 3)
        .scaleEffect(appeared ? 1 : 0.85)
        .opacity(appeared ? 1 : 0)
        .onAppear {
            withAnimation(.spring(response: 0.45, dampingFraction: 0.6)) { appeared = true }
        }
    }
}

/// Makes a tile feel pressable.
struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

enum KidGrid {
    /// Adaptive grid: 2 columns on phones, more on iPad.
    static func columns(minimum: CGFloat = 150) -> [GridItem] {
        [GridItem(.adaptive(minimum: minimum, maximum: 260), spacing: 14)]
    }
}
