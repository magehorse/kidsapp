import Foundation
import Observation

/// Replaces the Android `Utils.getPref/setPref` SharedPreferences usage.
@Observable
final class AppSettings {
    static let shared = AppSettings()

    private enum Key {
        static let userName = "USER_NAME"
        static let sound = "SOUND"
        static let language = "LANG"
        static let clickCount = "CLICK_IMAGE_COUNT"
        static let interstitialDay = "INTERSTITIAL_DAY"
        static let interstitialCount = "INTERSTITIAL_COUNT"
    }

    private let defaults: UserDefaults

    /// Child's display name, shown on the Home header. Empty until the first-launch dialog is answered.
    var userName: String {
        didSet { defaults.set(userName, forKey: Key.userName) }
    }

    /// Text-to-speech on/off (Android `Constant.SOUND`, default true).
    var soundOn: Bool {
        didSet { defaults.set(soundOn, forKey: Key.sound) }
    }

    /// "en" or "hi" - Hindi swaps the Numbers category titles to Devanagari.
    var language: String {
        didSet { defaults.set(language, forKey: Key.language) }
    }

    /// Alternates 1 -> 2 -> 1 ... : "first tap free, next tap may show an interstitial".
    var homeTapCount: Int {
        didSet { defaults.set(homeTapCount, forKey: Key.clickCount) }
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        userName = defaults.string(forKey: Key.userName) ?? ""
        soundOn = (defaults.object(forKey: Key.sound) as? Bool) ?? true
        language = defaults.string(forKey: Key.language) ?? "en"
        homeTapCount = (defaults.object(forKey: Key.clickCount) as? Int) ?? 1
    }

    // MARK: Interstitial daily cap

    /// Number of interstitials already shown today.
    func interstitialsShownToday() -> Int {
        let today = Self.dayStamp()
        guard defaults.string(forKey: Key.interstitialDay) == today else { return 0 }
        return defaults.integer(forKey: Key.interstitialCount)
    }

    func recordInterstitialShown() {
        let today = Self.dayStamp()
        let count = interstitialsShownToday() + 1
        defaults.set(today, forKey: Key.interstitialDay)
        defaults.set(count, forKey: Key.interstitialCount)
    }

    private static func dayStamp(_ date: Date = Date()) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return "\(c.year ?? 0)-\(c.month ?? 0)-\(c.day ?? 0)"
    }
}
