import SwiftUI

@main
struct KidsPlayApp: App {
    @State private var settings = AppSettings.shared
    @State private var router = Router()
    @State private var showSplash = true

    init() {
        AdService.shared.start()
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                RootView()
                    .environment(settings)
                    .environment(router)

                if showSplash {
                    SplashView()
                        .transition(.opacity)
                        .zIndex(1)
                }
            }
            .task {
                try? await Task.sleep(for: .seconds(1.6))
                withAnimation(.easeOut(duration: 0.4)) { showSplash = false }
            }
        }
    }
}

// MARK: - Root

struct RootView: View {
    @Environment(Router.self) private var router

    var body: some View {
        @Bindable var router = router
        NavigationStack(path: $router.path) {
            HomeView()
                .navigationDestination(for: Route.self) { route in
                    route.destination
                }
        }
        .tint(Theme.primaryBlue)
    }
}

// MARK: - Routing

/// Every screen the Android app reached with an `Intent` is a `Route` here.
enum Route: Hashable {
    case categoryGrid(type: Int)                 // HomeActivity  (1 learn, 2 look&choose, 3 listen&guess, 5 maths)
    case subCategory(position: Int, title: String) // SubActivity
    case flashCard(category: Int, selected: Int)   // FullScreenActivity
    case lookChoose(category: Int, title: String)  // LookChooseActivity
    case listenGuess(category: Int, title: String) // ListenGuessActivity
    case numberList                                // NumberListActivity
    case traceNumber(start: Int)                   // TraceNumberActivity
    case patternLevels                             // PatternLevelListActivity
    case matchingGame(roundSize: Int)              // MatchingGameActivity
    case drawPicker                                // BGImageListActivity
    case drawEditor(easy: Bool, index: Int)        // EditorActivity
    case reels                                     // ReelActivity
    case videos                                    // VideoLearningActivity
    case videoList(category: String)               // ListVideoActivity
    case mathsWorld                                // GameMenuActivity
    case settings                                  // SettingActivity
    case privacyPolicy                             // PrivacyPolicyActivity

    @ViewBuilder
    var destination: some View {
        switch self {
        case .categoryGrid(let type): CategoryGridView(type: type)
        case .subCategory(let position, let title): SubCategoryView(categoryID: position, title: title)
        case .flashCard(let category, let selected): FlashCardView(categoryID: category, startIndex: selected)
        case .lookChoose(let category, let title): LookChooseView(categoryID: category, title: title)
        case .listenGuess(let category, let title): ListenGuessView(categoryID: category, title: title)
        case .numberList: NumberListView()
        case .traceNumber(let start): TraceNumberView(startNumber: start)
        case .patternLevels: PatternLevelListView()
        case .matchingGame(let size): MatchingGameView(roundSize: size)
        case .drawPicker: DrawPickerView()
        case .drawEditor(let easy, let index): DrawingEditorView(isEasy: easy, index: index)
        case .reels: ReelView()
        case .videos: VideoLearningView()
        case .videoList(let category): VideoListView(category: category)
        case .mathsWorld: MathsWorldView()
        case .settings: SettingsView()
        case .privacyPolicy: PrivacyPolicyView()
        }
    }
}

@Observable
final class Router {
    var path = NavigationPath()

    func push(_ route: Route) { path.append(route) }
    func pop() { if !path.isEmpty { path.removeLast() } }
    func popToRoot() { path = NavigationPath() }
}

// MARK: - Keep the interactive swipe-back gesture when the nav bar is hidden

extension UINavigationController: @retroactive UIGestureRecognizerDelegate {
    override open func viewDidLoad() {
        super.viewDidLoad()
        interactivePopGestureRecognizer?.delegate = self
    }

    public func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        viewControllers.count > 1
    }
}
