import Foundation

/// Everything that was hard-coded in Android `Constant` / `CommonConstantAd` and is NOT inside the zip you sent.
/// Fill these in - each one is marked.
enum AppConfig {
    // MARK: Privacy policy (taken from PrivacyPolicyActivity.java)
    static let privacyPolicyURL = URL(string: "https://postkiyaapp.shivanshastrology.in/kidsplay/privacy-policy.html")!

    // MARK: Reels API  ->  TODO: copy from Android `ReelRetrofitInstance` + `Constant.REEL_CATEGORY_ID / REEL_TYPE`
    /// MUST be https on iOS (App Transport Security). Android allowed cleartext; iOS will block http.
    static let reelBaseURL = URL(string: "https://example.invalid/")!
    static let reelEndpointPath = "getVideos"
    static let reelCategoryID = "0"
    static let reelType = "video"

    // MARK: Ads  ->  OFF by default. See docs/APP_STORE_KIDS.md before turning on.
    static let adsEnabled: Bool = {
        #if ENABLE_ADS
        return true
        #else
        return false
        #endif
    }()
    /// Google's public TEST ids. Replace with your iOS ad units (Android ids do not work on iOS).
    static let bannerAdUnitID = "ca-app-pub-3940256099942544/2934735716"
    static let interstitialAdUnitID = "ca-app-pub-3940256099942544/4411468910"
    /// Android `MAX_INTERSTITIALS_PER_DAY` was not in the zip. Adjust to match.
    static let maxInterstitialsPerDay = 5

    // MARK: Update prompt
    /// Uses the public iTunes lookup for this bundle id (replaces Google Play in-app update check).
    static let checkForUpdates = true
}
