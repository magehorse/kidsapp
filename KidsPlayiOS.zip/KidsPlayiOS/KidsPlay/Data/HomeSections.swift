import Foundation

enum SectionAction {
    case subActivity   // opens SubCategoryView for `itemPositions[i]`
    case writingList   // "Learn Writing"  - number tracing
    case patternList   // "Match Pattern"
    case drawList      // "Draw"
    case video         // "Top Videos"
}

enum ItemArt: Hashable {
    case asset(String)
    case picture(DrawingPicture)
}

/// Android `HomeSectionModel`. The three parallel arrays are folded into one array of `Item`s,
/// which removes the whole class of "arrays out of sync" defensive checks the Java adapters needed.
struct HomeSection: Identifiable, Hashable {
    struct Item: Hashable {
        let title: String
        let art: ItemArt
        /// Meaning depends on `action`: category id / start number / round size / picture index.
        let position: Int
    }

    let id: String
    let title: String
    let items: [Item]
    let action: SectionAction

    init(title: String, action: SectionAction, items: [Item]) {
        self.id = title
        self.title = title
        self.action = action
        self.items = items
    }

    func filtered(matching query: String) -> HomeSection? {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        if q.isEmpty { return self }
        let kept = items.filter { $0.title.lowercased().contains(q) }
        return kept.isEmpty ? nil : HomeSection(title: title, action: action, items: kept)
    }

    static func == (lhs: HomeSection, rhs: HomeSection) -> Bool { lhs.id == rhs.id && lhs.items == rhs.items }
    func hash(into hasher: inout Hasher) { hasher.combine(id); hasher.combine(items) }
}

enum HomeSections {
    private static func assets(_ titles: [String], _ images: [String], _ positions: [Int], action: SectionAction, title: String) -> HomeSection {
        precondition(titles.count == images.count && images.count == positions.count, "\(title): section arrays out of sync")
        let items = (0..<titles.count).map {
            HomeSection.Item(title: titles[$0], art: .asset(images[$0]), position: positions[$0])
        }
        return HomeSection(title: title, action: action, items: items)
    }

    static func make(drawPreview: [DrawingPicture]) -> [HomeSection] {
        var sections: [HomeSection] = []

        sections.append(assets(
            ["Alphabets", "Body Parts", "Clothes", "Jobs", "School"],
            ["home_alphabet", "home_body_parts", "home_clothes", "home_jobs", "home_school"],
            [0, 10, 11, 16, 17], action: .subActivity, title: "English & Alphabets"))

        sections.append(assets(
            ["Numbers", "Shapes", "Geometry", "Month"],
            ["home_number", "home_shape", "home_geometry", "home_month"],
            [1, 3, 14, 8], action: .subActivity, title: "Mathematics"))

        sections.append(assets(
            ["Animals", "Birds", "Flowers", "Fruits", "Vegetable"],
            ["home_animal", "home_birds", "home_flower", "home_fruits", "home_vegetable"],
            [4, 5, 6, 7, 9], action: .subActivity, title: "Animals & Nature"))

        sections.append(assets(
            ["Colors", "Food", "Country", "House", "Sports", "Vehicle"],
            ["home_color", "home_food", "home_country", "home_house", "home_sports", "home_vehicle"],
            [2, 13, 12, 15, 18, 19], action: .subActivity, title: "Colors, Food & More"))

        sections.append(assets(
            ["Please", "Thank You", "Sorry"],
            ["please", "thank_you", "sorry"],
            [20, 20, 20], action: .subActivity, title: "Golden Words"))

        sections.append(assets(
            ["", "", "", ""],
            ["one_1", "two_2", "three_3", "four_4"],
            [1, 2, 3, 4], action: .writingList, title: "Learn Writing"))

        sections.append(assets(
            ["", "", "", "", ""],
            ["a_apple", "b_ball", "c_cat", "d_dog", "e_elephant"],
            [3, 4, 5, 6, 7], action: .patternList, title: "Match Pattern"))   // position = pair count for that level

        let previews = Array(drawPreview.prefix(4))
        if !previews.isEmpty {
            sections.append(HomeSection(
                title: "Draw", action: .drawList,
                items: previews.enumerated().map { HomeSection.Item(title: "", art: .picture($1), position: $0) }))
        }

        sections.append(assets(
            ["Standing Line", "Sleeping Line", "Slanting Line", "Zig Zag Line", "Curved Line", "Wavy Line"],
            ["line_standing", "line_sleeping", "line_slanting", "line_zigzag", "line_curved", "line_wavy"],
            [21, 21, 21, 21, 21, 21], action: .subActivity, title: "Lines"))

        sections.append(assets(
            ["Rhymes", "ABC Songs", "Number Songs", "Animal Songs", "Shape Songs", "Color Songs"],
            ["vt_abc", "vt_abc", "vt_number", "vt_animal", "vt_shape", "vt_color"],
            [0, 0, 0, 0, 0, 0], action: .video, title: "Top Videos"))

        return sections
    }
}
