import Foundation

/// Android `LearningDataModel(image, showTitle, speakTitle)`.
struct LearningItem: Codable, Hashable {
    /// Asset name (the Android drawable name, e.g. "a", "one_1", "polar_bear").
    let image: String
    /// Text shown on screen ("A for Apple").
    let title: String
    /// Text spoken aloud ("Apple").
    let speak: String
}

struct LearningCategory: Codable, Identifiable, Hashable {
    let id: Int
    let title: String
    let items: [LearningItem]
    /// Only the Numbers category has a Hindi variant (Android `LANG == "hi"`).
    let itemsHi: [LearningItem]?
}

private struct CategoryFile: Codable {
    let categories: [LearningCategory]
}

/// Single source of truth for all 22 categories.
/// Android duplicated this table in four Activities (SubActivity, FullScreenActivity,
/// LookChooseActivity, ListenGuessActivity) and the copies had drifted apart - see docs/MIGRATION_NOTES.md.
final class LearningRepository {
    static let shared: LearningRepository = {
        guard let url = Bundle.main.url(forResource: "categories", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let repo = try? LearningRepository(data: data) else {
            assertionFailure("categories.json missing or invalid")
            return LearningRepository(categories: [])
        }
        return repo
    }()

    let categories: [LearningCategory]

    init(categories: [LearningCategory]) {
        self.categories = categories
    }

    convenience init(data: Data) throws {
        let file = try JSONDecoder().decode(CategoryFile.self, from: data)
        self.init(categories: file.categories)
    }

    func category(_ id: Int) -> LearningCategory? {
        categories.first { $0.id == id }
    }

    /// Items for a category, honoring the language setting where a variant exists.
    func items(for categoryID: Int, language: String = AppSettings.shared.language) -> [LearningItem] {
        guard let category = category(categoryID) else { return [] }
        if language == "hi", let hindi = category.itemsHi { return hindi }
        return category.items
    }

    // MARK: Home grid artwork (HomeActivity.mainCategoryList / homeCategoryTitles)

    static let homeImages: [String] = [
        "home_alphabet", "home_number", "home_color", "home_shape", "home_animal",
        "home_birds", "home_flower", "home_fruits", "home_month", "home_vegetable",
        "home_body_parts", "home_clothes", "home_country", "home_food", "home_geometry",
        "home_house", "home_jobs", "home_school", "home_sports", "home_vehicle",
        "home_golden", "line_zigzag"
    ]

    static let homeTitles: [String] = [
        "Alphabets", "Numbers", "Colors", "Shapes", "Animals",
        "Birds", "Flowers", "Fruits", "Month", "Vegetable",
        "Body Parts", "Clothes", "Country", "Food", "Geometry",
        "House", "Jobs", "School", "Sports", "Vehicle",
        "Golden Words", "Lines"
    ]

    /// Category ids shown by the Mathematics grid (HomeActivity type 5): Numbers, Shapes, Geometry, Month.
    static let mathCategoryIDs = [1, 3, 14, 8]
}
