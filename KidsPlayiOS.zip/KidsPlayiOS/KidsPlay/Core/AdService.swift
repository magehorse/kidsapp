import SwiftUI

#if ENABLE_ADS && canImport(GoogleMobileAds)
import GoogleMobileAds
#endif

/// Thin wrapper around the ad SDK so the rest of the app never imports it.
///
/// IMPORTANT: ads are compiled OUT by default. Apple's Kids Category (guideline 1.3) does not allow
/// third-party advertising. See docs/APP_STORE_KIDS.md before defining ENABLE_ADS.
@MainActor
final class AdService: NSObject {
    static let shared = AdService()

    #if ENABLE_ADS && canImport(GoogleMobileAds)
    private var interstitial: InterstitialAd?
    private var pendingCompletion: (() -> Void)?
    #endif

    private override init() { super.init() }

    func start() {
        guard AppConfig.adsEnabled else { return }
        #if ENABLE_ADS && canImport(GoogleMobileAds)
        let config = MobileAds.shared.requestConfiguration
        config.tagForChildDirectedTreatment = true
        config.tagForUnderAgeOfConsent = true
        config.maxAdContentRating = .general
        MobileAds.shared.start(completionHandler: nil)
        preloadInterstitial()
        #endif
    }

    func preloadInterstitial() {
        guard AppConfig.adsEnabled else { return }
        #if ENABLE_ADS && canImport(GoogleMobileAds)
        guard interstitial == nil else { return }
        Task {
            do {
                interstitial = try await InterstitialAd.load(with: AppConfig.interstitialAdUnitID, request: Request())
                interstitial?.fullScreenContentDelegate = self
            } catch {
                interstitial = nil
            }
        }
        #endif
    }

    /// Shows an interstitial if one is ready and today's cap is not hit; otherwise runs `completion` straight away.
    func showInterstitial(then completion: @escaping () -> Void) {
        guard AppConfig.adsEnabled,
              AppSettings.shared.interstitialsShownToday() < AppConfig.maxInterstitialsPerDay else {
            completion()
            return
        }
        #if ENABLE_ADS && canImport(GoogleMobileAds)
        guard let ad = interstitial, let root = UIApplication.shared.topViewController else {
            preloadInterstitial()
            completion()
            return
        }
        pendingCompletion = completion
        AppSettings.shared.recordInterstitialShown()
        ad.present(from: root)
        #else
        completion()
        #endif
    }
}

#if ENABLE_ADS && canImport(GoogleMobileAds)
extension AdService: FullScreenContentDelegate {
    func adDidDismissFullScreenContent(_ ad: FullScreenPresentingAd) {
        interstitial = nil
        let done = pendingCompletion
        pendingCompletion = nil
        preloadInterstitial()
        done?()
    }

    func ad(_ ad: FullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
        interstitial = nil
        let done = pendingCompletion
        pendingCompletion = nil
        done?()
    }
}
#endif

// MARK: - Home tile gating (MainActivity.runFromHomeWithInterstitial)

enum HomeAdGate {
    /// "First tap free, every other tap may show an interstitial" - only for the 4 top-page tiles.
    @MainActor
    static func run(navigate: @escaping () -> Void) {
        let settings = AppSettings.shared
        if settings.homeTapCount == 1 {
            settings.homeTapCount = 2
            navigate()
        } else {
            settings.homeTapCount = 1
            AdService.shared.showInterstitial(then: navigate)
        }
    }
}

// MARK: - Banner

/// Draws nothing unless ads are enabled - so screens can always include it.
struct BannerAdView: View {
    var body: some View {
        #if ENABLE_ADS && canImport(GoogleMobileAds)
        if AppConfig.adsEnabled {
            AdMobBanner()
                .frame(height: 50)
                .frame(maxWidth: .infinity)
        }
        #else
        EmptyView()
        #endif
    }
}

#if ENABLE_ADS && canImport(GoogleMobileAds)
private struct AdMobBanner: UIViewRepresentable {
    func makeUIView(context: Context) -> BannerView {
        let banner = BannerView(adSize: AdSizeBanner)
        banner.adUnitID = AppConfig.bannerAdUnitID
        banner.rootViewController = UIApplication.shared.topViewController
        banner.load(Request())
        return banner
    }

    func updateUIView(_ uiView: BannerView, context: Context) {}
}
#endif

extension UIApplication {
    /// Top-most view controller of the foreground window scene.
    var topViewController: UIViewController? {
        let scene = connectedScenes.compactMap { $0 as? UIWindowScene }.first { $0.activationState == .foregroundActive }
        var top = scene?.keyWindow?.rootViewController
        while let presented = top?.presentedViewController { top = presented }
        return top
    }
}
