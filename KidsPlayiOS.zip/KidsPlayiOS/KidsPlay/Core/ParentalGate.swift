import SwiftUI

/// A simple "grown-ups only" check. Required by Apple for kids apps before anything that leaves
/// the app (web pages, App Store links) or exposes a purchase/settings surface.
struct ParentalGateView: View {
    let onPass: () -> Void
    let onCancel: () -> Void

    @State private var challenge = Challenge.random()
    @State private var wrongTries = 0

    struct Challenge {
        let a: Int
        let b: Int
        let options: [Int]

        var answer: Int { a * b }

        static func random() -> Challenge {
            let a = Int.random(in: 6...9)
            let b = Int.random(in: 6...9)
            var options: Set<Int> = [a * b]
            while options.count < 3 {
                let delta = [-10, -8, -6, -4, -2, 2, 4, 6, 8, 10].randomElement() ?? 2
                let candidate = a * b + delta
                if candidate > 0 { options.insert(candidate) }
            }
            return Challenge(a: a, b: b, options: options.shuffled())
        }
    }

    var body: some View {
        VStack(spacing: 22) {
            Text("Grown-ups only")
                .font(Theme.font(22, relativeTo: .title2))
                .foregroundStyle(Theme.headerBottom)

            Text("Ask a grown-up to solve this to continue.")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)

            Text("\(challenge.a) × \(challenge.b) = ?")
                .font(Theme.font(38, relativeTo: .largeTitle))

            HStack(spacing: 14) {
                ForEach(challenge.options, id: \.self) { option in
                    Button {
                        if option == challenge.answer {
                            onPass()
                        } else {
                            wrongTries += 1
                            Haptics.error()
                            challenge = .random()
                        }
                    } label: {
                        Text("\(option)")
                            .font(Theme.font(24, relativeTo: .title2))
                            .frame(width: 84, height: 60)
                            .background(Theme.sunYellow.opacity(0.9), in: RoundedRectangle(cornerRadius: 16))
                            .foregroundStyle(.black)
                    }
                    .accessibilityLabel("Answer \(option)")
                }
            }

            if wrongTries > 0 {
                Text("Not quite - here is a new one.")
                    .font(.footnote)
                    .foregroundStyle(Theme.wrongRed)
            }

            Button("Cancel", role: .cancel, action: onCancel)
                .padding(.top, 4)
        }
        .padding(28)
        .frame(maxWidth: 420)
        .background(.background, in: RoundedRectangle(cornerRadius: 28))
        .padding(24)
    }
}

extension View {
    /// Presents the parental gate; runs `action` only after it is solved.
    func parentalGate(isPresented: Binding<Bool>, onPass action: @escaping () -> Void) -> some View {
        fullScreenCover(isPresented: isPresented) {
            ZStack {
                Color.black.opacity(0.45).ignoresSafeArea()
                ParentalGateView(
                    onPass: {
                        isPresented.wrappedValue = false
                        // let the cover dismiss before navigating / opening URLs
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35, execute: action)
                    },
                    onCancel: { isPresented.wrappedValue = false }
                )
            }
            .presentationBackground(.clear)
        }
    }
}

// MARK: - Update check (replaces Google Play AppUpdateManager)

struct AppUpdateInfo: Equatable {
    let latestVersion: String
    let storeURL: URL
}

enum UpdateChecker {
    private struct LookupResponse: Decodable {
        struct Result: Decodable { let version: String; let trackViewUrl: String }
        let results: [Result]
    }

    /// Returns info only if the App Store has a newer version than the installed one.
    static func newerVersionAvailable() async -> AppUpdateInfo? {
        guard AppConfig.checkForUpdates,
              let bundleID = Bundle.main.bundleIdentifier,
              let installed = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String,
              let url = URL(string: "https://itunes.apple.com/lookup?bundleId=\(bundleID)") else { return nil }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let response = try JSONDecoder().decode(LookupResponse.self, from: data)
            guard let result = response.results.first,
                  let storeURL = URL(string: result.trackViewUrl),
                  isVersion(result.version, newerThan: installed) else { return nil }
            return AppUpdateInfo(latestVersion: result.version, storeURL: storeURL)
        } catch {
            return nil   // silent - never block the UI (same as Android)
        }
    }

    static func isVersion(_ candidate: String, newerThan installed: String) -> Bool {
        candidate.compare(installed, options: .numeric) == .orderedDescending
    }
}
