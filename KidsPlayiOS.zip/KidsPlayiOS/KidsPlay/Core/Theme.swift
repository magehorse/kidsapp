import SwiftUI

extension Color {
    /// `Color(hex: 0x5B92F5)` or `Color(hex: "#5B92F5")`
    init(hex: UInt32, opacity: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: opacity
        )
    }

    init(hex string: String) {
        let cleaned = string.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var value: UInt64 = 0
        Scanner(string: cleaned).scanHexInt64(&value)
        if cleaned.count == 8 {
            // Android ARGB
            self.init(
                .sRGB,
                red: Double((value >> 16) & 0xFF) / 255,
                green: Double((value >> 8) & 0xFF) / 255,
                blue: Double(value & 0xFF) / 255,
                opacity: Double((value >> 24) & 0xFF) / 255
            )
        } else {
            self.init(hex: UInt32(value & 0xFFFFFF))
        }
    }
}

enum Theme {
    // colors_home_kids.xml
    static let headerTop = Color(hex: 0x5B92F5)
    static let headerBottom = Color(hex: 0x3A6FD8)
    static let pageTop = Color(hex: 0xEAF4FF)
    static let pageBottom = Color(hex: 0xFFF6E0)
    static let sunYellow = Color(hex: 0xFFC107)

    // kidsdrawing colors.xml
    static let primaryBlue = Color(hex: 0x028BFF)      // kd_colorTheme
    static let matchHeader = Color(hex: 0x3A6FD8)      // kd_matchHeaderTheme

    /// Home "Top Category" tile colours (MainActivity.categoryColors)
    static let topCategoryColors: [Color] = [
        Color(hex: 0xA8E6A1), Color(hex: 0xC9B6F5), Color(hex: 0xFBC4E0), Color(hex: 0xFFD59E)
    ]

    /// HomeSectionAdapter.ACCENT_COLORS
    static let sectionAccents: [Color] = [
        Color(hex: 0xFFB300), Color(hex: 0xFF7043), Color(hex: 0x26C6DA),
        Color(hex: 0x66BB6A), Color(hex: 0xAB47BC), Color(hex: 0x5C6BC0)
    ]

    /// Letters of `ColorfulTitle` cycle through these.
    static let titleLetters: [Color] = [
        Color(hex: 0xE53935), Color(hex: 0xFB8C00), Color(hex: 0x43A047),
        Color(hex: 0x1E88E5), Color(hex: 0x8E24AA), Color(hex: 0xD81B60)
    ]

    static let correctGreen = Color(hex: 0x4CAF50)
    static let wrongRed = Color(hex: 0xEF5350)
    static let neutralText = Color(hex: 0x455A64)

    static func font(_ size: CGFloat, relativeTo style: Font.TextStyle = .body) -> Font {
        .custom("Poppins-Bold", size: size, relativeTo: style)
    }

    static var pageGradient: LinearGradient {
        LinearGradient(colors: [pageTop, pageBottom], startPoint: .top, endPoint: .bottom)
    }

    static var headerGradient: LinearGradient {
        LinearGradient(colors: [headerTop, headerBottom], startPoint: .top, endPoint: .bottom)
    }
}
