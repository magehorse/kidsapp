import AVFoundation
import UIKit

/// Replaces `AppControl.textToSpeech` (Android `TextToSpeech`).
/// One shared synthesizer so a new word always interrupts the previous one (`QUEUE_FLUSH`).
@MainActor
final class SpeechService {
    static let shared = SpeechService()

    private let synthesizer = AVSpeechSynthesizer()
    private var sessionConfigured = false

    private init() {}

    /// Speaks `text` if the child has sound enabled. Pass `force: true` for UI that must always speak.
    func speak(_ text: String, force: Bool = false) {
        guard force || AppSettings.shared.soundOn else { return }
        guard !text.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        configureSessionIfNeeded()

        if synthesizer.isSpeaking { synthesizer.stopSpeaking(at: .immediate) }

        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        utterance.rate = 0.42            // a little slower than default: it is for children
        utterance.pitchMultiplier = 1.1
        utterance.postUtteranceDelay = 0.05
        synthesizer.speak(utterance)
    }

    func stop() {
        if synthesizer.isSpeaking { synthesizer.stopSpeaking(at: .immediate) }
    }

    private func configureSessionIfNeeded() {
        guard !sessionConfigured else { return }
        sessionConfigured = true
        // .playback so speech is audible even with the ring/silent switch on - expected for a learning app.
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
        try? AVAudioSession.sharedInstance().setActive(true)
    }
}

enum Haptics {
    @MainActor static func success() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
    @MainActor static func error() { UINotificationFeedbackGenerator().notificationOccurred(.error) }
    @MainActor static func tap() { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
}
