# Shipping this on the App Store (Kids Category checklist)

Verify against Apple's *current* App Review Guidelines (1.3 Kids Category, 5.1.4) – they change.

1. **No third-party ads or analytics in the Kids Category.** That means **AdMob must stay off** if you choose
   "Made for Kids". `AppConfig.adsEnabled` is false, `ENABLE_ADS` is not defined, and a unit test guards it.
   Options: (a) ship ad-free (recommended), (b) ship *outside* the Kids Category as a general app with
   child-directed treatment tags (already set in `AdService`) – you lose the Kids badge, (c) replace ads with a
   paid "remove ads"/one-time unlock (needs StoreKit + parental gate).
2. **Parental gate** before anything that leaves the app or is aimed at adults: implemented for the Privacy
   Policy link and the App Store update link (`ParentalGate.swift`). Use it for any future links/purchases.
3. **Privacy policy URL** (already in `AppConfig`) must be set in App Store Connect too, and must say no
   personal data is collected. `PrivacyInfo.xcprivacy` declares no tracking and no collected data.
4. **Privacy "nutrition label":** Data Not Collected – provided the Reels server sees only ordinary requests.
5. **Age rating / audience:** choose 5 and under or 6–8 as appropriate.
6. **Reels and YouTube:** content fetched from your server / YouTube must be suitable for children at all times.
   The YouTube player blocks navigation and hides related-video links, but YouTube's embed can still show
   suggestions at the end – consider hosting your own videos, or submit a review note explaining the source.
   If the embed shows "Error 153", set the web view `baseURL` to a domain you own.
7. **Photos permission** is add-only (`NSPhotoLibraryAddUsageDescription`) – the app never reads the library.
8. **Data at rest:** the only stored data is the child's first name in `UserDefaults`. Keep it that way.
9. Bump `MARKETING_VERSION` / `CURRENT_PROJECT_VERSION` in `project.yml` for every upload.
