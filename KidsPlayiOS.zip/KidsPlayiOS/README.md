# Kids Learning – native iOS (SwiftUI)

A ground-up native iOS port of your Android app (`com.kidsplay.kidseducation` + the `kidsdrawing` module).
SwiftUI, iOS 17+, Swift 5.9+, **no third-party dependencies**, Xcode 16 or newer.

> **Honest status:** this was written and syntax-checked without access to Xcode or a Mac, so it has **not been
> compiled or run on a simulator yet**. Expect a handful of small compiler fixes on first build (typically
> access-level or type-inference nits). The logic layers (quiz, tracing, playlist, settings, data) have unit tests
> in `KidsPlayTests/` – run them first. See "What I could not port" below: the zip you sent was a *partial*
> "changed files" export, so some screens are rebuilt from what the code implied.

## 5-minute setup

```bash
brew install xcodegen
cd KidsPlayiOS

# 1. Copy artwork from the Android project (about 470 images + colouring pages)
pip install pillow
python3 tools/import_android_assets.py \
  --android-res  /path/to/KidsPlay/app/src/main/res \
  --drawing-easy /path/to/KidsPlay/kidsdrawing/src/main/assets/easy \
  --drawing-hard /path/to/KidsPlay/kidsdrawing/src/main/assets/hard

# 2. Generate the Xcode project
xcodegen generate
open KidsPlay.xcodeproj
```

Then in Xcode: set your **Team** (or `DEVELOPMENT_TEAM` in `project.yml`), pick an iPhone simulator, ⌘R.
Run tests with ⌘U.

Until step 1 is done every picture shows a coloured letter placeholder, so the whole app is still navigable.

## Fill in these (they were not in the zip) – `KidsPlay/App/AppConfig.swift`

| Setting | Where it came from on Android |
|---|---|
| `reelBaseURL`, `reelEndpointPath`, `reelCategoryID`, `reelType` | `ReelRetrofitInstance`, `Constant.REEL_*` – **must be https** (iOS App Transport Security blocks http) |
| `Resources/Data/videos.json` | YouTube ids for Video Songs (`VideoLearningActivity` was not in the zip) |
| Ad unit ids (optional) | Android ids do not work on iOS – see `docs/APP_STORE_KIDS.md` first |

## Android → iOS map

| Android | iOS |
|---|---|
| `MainActivity` (+ sections, search, name dialog, update dialog) | `Features/Home/HomeView.swift` |
| `HomeActivity` (types 1/2/3/5) | `CategoryGridView` |
| `SubActivity` | `SubCategoryView` |
| `FullScreenActivity` (flash cards) | `FlashCardView` |
| `LookChooseActivity` / `ListenGuessActivity` | `LookChooseView` / `ListenGuessView` + `QuizEngine` |
| `NumberListActivity` / `TraceNumberActivity` | `NumberListView` / `TraceNumberView` + `GlyphSampler` |
| `PatternLevelListActivity` / `MatchingGameActivity` | `PatternLevelListView` / `MatchingGameView` |
| `BGImageListActivity` / `EditorActivity` | `DrawPickerView` / `DrawingEditorView` |
| `ReelActivity` | `ReelView` (vertical `ScrollView` paging + `AVPlayer`) |
| `PrivacyPolicyActivity` | `PrivacyPolicyView` (WKWebView) |
| 4 duplicated data tables in Java | one `categories.json` + `LearningRepository` |
| `TextToSpeech` | `AVSpeechSynthesizer` (`SpeechService`) |
| `SharedPreferences` | `UserDefaults` (`AppSettings`) |
| Google Play in-app update | iTunes lookup + "Update available" sheet behind a parental gate |
| AdMob banners/interstitials | `AdService` – **compiled out by default** |

## Status

| Feature | State |
|---|---|
| Home, categories, flash cards, Look & Choose, Listen & Guess | Ported, data-complete (22 categories, 492 items, Hindi numbers) |
| Number tracing (1–20) | Ported; approach changed (see notes) |
| Match Pattern | Ported; `LetterPictureRepository` rebuilt from Alphabets |
| Drawing (brush, pencil, magic, stickers, text, undo/redo, save) | Ported; saves to Photos; stickers are emoji |
| Kids Reel | Ported; needs your API details |
| Video Songs | Rebuilt; needs `videos.json` |
| Settings, Privacy Policy | Settings rebuilt (see below), policy ported |
| **Maths World** (`GameMenuActivity`, `GameActivity`, `ResultsActivity`) | **Not in zip** – tile opens the maths category grid instead |
| "My Work" gallery | **Not in zip** – finished drawings go to the Photos library |

## What I could not port (files missing from the zip)

`GameMenuActivity`, `GameActivity`, `ResultsActivity`, `SettingActivity`, `VideoLearningActivity`,
`ListVideoActivity`, `VideoPlayActivity`, `ReelModel`/Retrofit classes, `LetterPictureRepository`, `Constant`,
`CommonConstantAd`, every image/asset, the drawing module's `assets/` folder. Send those and I will port them
properly; everything above marked "rebuilt" is a best reconstruction from how the other files call them.
