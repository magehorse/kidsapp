import XCTest
import SwiftUI
@testable import KidsPlay

// MARK: - Deterministic RNG for repeatable quiz tests

struct SeededGenerator: RandomNumberGenerator {
    private var state: UInt64
    init(seed: UInt64) { state = seed }
    mutating func next() -> UInt64 {
        state &+= 0x9E3779B97F4A7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        return z ^ (z >> 31)
    }
}

// MARK: - Learning data

final class LearningRepositoryTests: XCTestCase {
    private let repo = LearningRepository.shared

    func testAll22CategoriesLoadInOrder() {
        XCTAssertEqual(repo.categories.count, 22)
        XCTAssertEqual(repo.categories.map(\.id), Array(0..<22))
        XCTAssertEqual(repo.categories.map(\.title), LearningRepository.homeTitles)
    }

    func testHomeArraysAreInSync() {
        XCTAssertEqual(LearningRepository.homeTitles.count, 22)
        XCTAssertEqual(LearningRepository.homeImages.count, 22)
    }

    func testEveryCategoryCanRunAQuiz() {
        for category in repo.categories {
            XCTAssertGreaterThanOrEqual(category.items.count, 4, "\(category.title) needs 4+ items for a 4-option quiz")
        }
    }

    func testNoEmptyFields() {
        for category in repo.categories {
            for item in category.items {
                XCTAssertFalse(item.image.isEmpty, category.title)
                XCTAssertFalse(item.title.isEmpty, category.title)
                XCTAssertFalse(item.speak.isEmpty, category.title)
            }
        }
    }

    func testNoDuplicateImagesInsideACategory() {
        for category in repo.categories {
            let names = category.items.map(\.image)
            XCTAssertEqual(names.count, Set(names).count, "duplicate image in \(category.title)")
        }
    }

    func testHindiVariantOnlyOnNumbers() {
        let withHindi = repo.categories.filter { $0.itemsHi != nil }
        XCTAssertEqual(withHindi.map(\.id), [1])
        XCTAssertEqual(withHindi.first?.itemsHi?.count, repo.category(1)?.items.count)
        XCTAssertEqual(repo.items(for: 1, language: "hi").first?.title, "शून्य")
        XCTAssertEqual(repo.items(for: 1, language: "en").first?.title, "Zero")
        XCTAssertEqual(repo.items(for: 2, language: "hi").count, repo.items(for: 2, language: "en").count)
    }

    func testUnknownCategoryIsEmptyNotACrash() {
        XCTAssertTrue(repo.items(for: 99).isEmpty)
    }

    func testHomeSectionsBuildAndFilter() {
        let sections = HomeSections.make(drawPreview: [])
        XCTAssertFalse(sections.isEmpty)
        let maths = sections.first { $0.title == "Mathematics" }
        XCTAssertEqual(maths?.items.map(\.position), [1, 3, 14, 8])
        XCTAssertEqual(maths?.filtered(matching: "num")?.items.count, 1)
        XCTAssertNil(maths?.filtered(matching: "zzzz"))
        XCTAssertEqual(maths?.filtered(matching: "  ")?.items.count, 4)
    }
}

// MARK: - Quiz

final class QuizEngineTests: XCTestCase {
    private func items(_ n: Int) -> [LearningItem] {
        (0..<n).map { LearningItem(image: "img\($0)", title: "T\($0)", speak: "S\($0)") }
    }

    func testFourDistinctOptionsContainingTheAnswerOnce() {
        var rng = SeededGenerator(seed: 1)
        for _ in 0..<200 {
            let q = QuizEngine.makeQuestion(from: items(10), using: &rng)!
            XCTAssertEqual(q.options.count, 4)
            XCTAssertEqual(Set(q.options).count, 4)
            XCTAssertEqual(q.options.filter { $0 == q.correct }.count, 1)
            XCTAssertEqual(q.options[q.correctIndex], q.correct)
        }
    }

    func testTinyCategoriesNeverHang() {
        var rng = SeededGenerator(seed: 2)
        let q = QuizEngine.makeQuestion(from: items(2), using: &rng)!
        XCTAssertEqual(q.options.count, 2)
        let q3 = QuizEngine.makeQuestion(from: items(3), using: &rng)!
        XCTAssertEqual(q3.options.count, 3)
    }

    func testNotEnoughItemsReturnsNil() {
        var rng = SeededGenerator(seed: 3)
        XCTAssertNil(QuizEngine.makeQuestion(from: items(1), using: &rng))
        XCTAssertNil(QuizEngine.makeQuestion(from: [], using: &rng))
    }

    func testDoesNotRepeatThePreviousAnswer() {
        var rng = SeededGenerator(seed: 4)
        let list = items(6)
        for _ in 0..<200 {
            let q = QuizEngine.makeQuestion(from: list, avoiding: list[2], using: &rng)!
            XCTAssertNotEqual(q.correct, list[2])
        }
    }

    func testSessionWrongThenRight() {
        let session = QuizSession(items: items(8))
        let question = session.question!
        let wrong = (0..<question.options.count).first { $0 != question.correctIndex }!

        XCTAssertFalse(session.choose(wrong))
        XCTAssertTrue(session.wrongIndices.contains(wrong))
        XCTAssertFalse(session.isSolved)

        XCTAssertFalse(session.choose(wrong), "same wrong tap twice does nothing")
        XCTAssertTrue(session.choose(question.correctIndex))
        XCTAssertTrue(session.isSolved)
        XCTAssertFalse(session.choose(wrong), "no taps after solved")

        session.next()
        XCTAssertFalse(session.isSolved)
        XCTAssertTrue(session.wrongIndices.isEmpty)
    }
}

// MARK: - Tracing

final class TracingTests: XCTestCase {
    func testGlyphHasSamplePointsInsideBounds() {
        for digit in ["1", "8", "20"] {
            let g = GlyphSampler.make(text: digit)
            XCTAssertGreaterThan(g.points.count, 60, "digit \(digit)")
            XCTAssertTrue(g.points.allSatisfy { $0.x >= 0 && $0.x <= g.sideLength && $0.y >= 0 && $0.y <= g.sideLength })
        }
    }

    func testTouchingNothingIsNotComplete() {
        let progress = TraceProgress(sample: GlyphSampler.make(text: "3"))
        XCTAssertEqual(progress.fraction, 0)
        XCTAssertFalse(progress.isComplete)
    }

    func testTouchingEverySamplePointCompletes() {
        var progress = TraceProgress(sample: GlyphSampler.make(text: "5"))
        for p in progress.sample.points { progress.touch(p) }
        XCTAssertEqual(progress.fraction, 1, accuracy: 0.0001)
        XCTAssertTrue(progress.isComplete)
    }

    func testTouchingOutsideTheGlyphDoesNothing() {
        var progress = TraceProgress(sample: GlyphSampler.make(text: "1"))
        progress.touch(CGPoint(x: -500, y: -500))
        XCTAssertEqual(progress.coveredCount, 0)
    }

    func testPartialCoverageBelowThreshold() {
        var progress = TraceProgress(sample: GlyphSampler.make(text: "7"), completionThreshold: 0.85)
        let half = progress.sample.points.prefix(progress.sample.points.count / 3)
        for p in half { progress.touch(p) }
        XCTAssertFalse(progress.isComplete)
        XCTAssertGreaterThan(progress.fraction, 0.2)
    }
}

// MARK: - Matching

final class MatchingTests: XCTestCase {
    func testLettersBuiltFromAlphabets() {
        let letters = LetterPictureRepository.build(from: LearningRepository.shared.items(for: 0), imageExists: { _ in false })
        XCTAssertEqual(letters.count, 26)
        XCTAssertEqual(letters.first?.letter, "A")
        XCTAssertEqual(letters.last?.letter, "Z")
    }

    func testRoundSizeIsClamped() {
        let pool = LetterPictureRepository.build(from: LearningRepository.shared.items(for: 0), imageExists: { _ in false })
        XCTAssertEqual(LetterPictureRepository.randomRound(size: 5, from: pool).count, 5)
        XCTAssertEqual(LetterPictureRepository.randomRound(size: 0, from: pool).count, 2)
        XCTAssertEqual(LetterPictureRepository.randomRound(size: 999, from: pool).count, 26)
        let round = LetterPictureRepository.randomRound(size: 7, from: pool)
        XCTAssertEqual(round.map(\.letter), round.map(\.letter).sorted())
        XCTAssertEqual(Set(round.map(\.letter)).count, 7)
    }
}

// MARK: - Reels

final class ReelTests: XCTestCase {
    private func urls(_ n: Int) -> [URL] { (0..<n).map { URL(string: "https://x.test/\($0).mp4")! } }

    func testLoadStartsWithOneShuffledRound() {
        var list = ReelPlaylist()
        list.load(urls(5))
        XCTAssertEqual(list.entries.count, 5)
        XCTAssertEqual(Set(list.entries.map(\.url)), Set(urls(5)))
        XCTAssertEqual(list.entries.map(\.id), Array(0..<5))
    }

    func testAppendingRoundsKeepsSourceIntactAndIdsSequential() {
        var list = ReelPlaylist()
        list.load(urls(4))
        list.appendRound()
        list.appendRound()
        XCTAssertEqual(list.entries.count, 12)
        XCTAssertEqual(list.source.count, 4)
        XCTAssertEqual(list.entries.map(\.id), Array(0..<12))
        // each whole round contains every video exactly once
        for round in stride(from: 0, to: 12, by: 4) {
            XCTAssertEqual(Set(list.entries[round..<round + 4].map(\.url)).count, 4)
        }
    }

    func testNeedsMoreNearTheEnd() {
        var list = ReelPlaylist()
        list.load(urls(5))
        XCTAssertFalse(list.needsMore(at: 0))
        XCTAssertFalse(list.needsMore(at: 2))
        XCTAssertTrue(list.needsMore(at: 3))
        XCTAssertTrue(list.needsMore(at: 4))
    }

    func testEmptySourceNeverCrashes() {
        var list = ReelPlaylist()
        list.load([])
        list.appendRound()
        XCTAssertTrue(list.isEmpty)
        XCTAssertFalse(list.needsMore(at: 0))
    }

    func testModelDecodingIsForgiving() throws {
        let json = """
        [ {"image":"https://x.test/a.mp4","is_video":1},
          {"image":"https://x.test/b.mp4","is_video":"true"},
          {"image":"https://x.test/c.mp4"},
          {"image":"https://x.test/d.png","is_video":0},
          {"image":null},
          {"image":"https://x.test/e.mp4","is_video":false} ]
        """.data(using: .utf8)!
        let models = try JSONDecoder().decode([ReelModel].self, from: json)
        let playable = ReelPlaylist.playableURLs(from: models).map(\.lastPathComponent)
        XCTAssertEqual(playable, ["a.mp4", "b.mp4", "c.mp4"])
    }
}

// MARK: - Settings + update check

final class SettingsTests: XCTestCase {
    private func freshDefaults() -> UserDefaults {
        let suite = "kidsplay.tests.\(UUID().uuidString)"
        let d = UserDefaults(suiteName: suite)!
        d.removePersistentDomain(forName: suite)
        return d
    }

    func testDefaultsMatchAndroid() {
        let s = AppSettings(defaults: freshDefaults())
        XCTAssertEqual(s.userName, "")
        XCTAssertTrue(s.soundOn)
        XCTAssertEqual(s.language, "en")
        XCTAssertEqual(s.homeTapCount, 1)
    }

    func testPersistsAcrossInstances() {
        let d = freshDefaults()
        let a = AppSettings(defaults: d)
        a.userName = "Aarav"
        a.soundOn = false
        a.language = "hi"
        let b = AppSettings(defaults: d)
        XCTAssertEqual(b.userName, "Aarav")
        XCTAssertFalse(b.soundOn)
        XCTAssertEqual(b.language, "hi")
    }

    func testInterstitialCounterCounts() {
        let s = AppSettings(defaults: freshDefaults())
        XCTAssertEqual(s.interstitialsShownToday(), 0)
        s.recordInterstitialShown()
        s.recordInterstitialShown()
        XCTAssertEqual(s.interstitialsShownToday(), 2)
    }

    func testInterstitialCounterResetsOnANewDay() {
        let d = freshDefaults()
        d.set("2000-1-1", forKey: "INTERSTITIAL_DAY")
        d.set(9, forKey: "INTERSTITIAL_COUNT")
        XCTAssertEqual(AppSettings(defaults: d).interstitialsShownToday(), 0)
    }

    func testVersionComparisonIsNumeric() {
        XCTAssertTrue(UpdateChecker.isVersion("1.10.0", newerThan: "1.9.0"))
        XCTAssertTrue(UpdateChecker.isVersion("2.0", newerThan: "1.9.9"))
        XCTAssertFalse(UpdateChecker.isVersion("1.0.0", newerThan: "1.0.0"))
        XCTAssertFalse(UpdateChecker.isVersion("1.0", newerThan: "1.0.1"))
    }

    func testAdsAreOffByDefault() {
        XCTAssertFalse(AppConfig.adsEnabled, "Kids Category apps must not ship third-party ads")
    }
}

// MARK: - Drawing model

@MainActor
final class DrawingModelTests: XCTestCase {
    func testUndoRedo() {
        let m = DrawingModel()
        m.tool = .brush
        m.beginStroke(at: .zero); m.extendStroke(to: CGPoint(x: 5, y: 5))
        m.beginStroke(at: CGPoint(x: 20, y: 20))
        XCTAssertEqual(m.strokes.count, 2)
        m.undo()
        XCTAssertEqual(m.strokes.count, 1)
        XCTAssertTrue(m.canRedo)
        m.redo()
        XCTAssertEqual(m.strokes.count, 2)
        m.beginStroke(at: .zero)                     // a new stroke discards the redo history
        XCTAssertFalse(m.canRedo)
    }

    func testEmptyCanvasHasNoContent() {
        XCTAssertFalse(DrawingModel().hasContent)
    }

    func testStickersAndTextCountAsContent() {
        let m = DrawingModel()
        m.addSticker("⭐️", at: .zero)
        XCTAssertTrue(m.hasContent)
        let id = m.stickers[0].id
        m.delete(id)
        XCTAssertFalse(m.hasContent)
        m.addText("Hi", color: .red, face: .rounded, at: .zero)
        XCTAssertTrue(m.hasContent)
    }

    func testMagicStampsAreSpacedOut() {
        let m = DrawingModel()
        m.tool = .magic
        m.beginStroke(at: .zero)
        for x in stride(from: 1, through: 20, by: 1) { m.extendStroke(to: CGPoint(x: CGFloat(x), y: 0)) }
        XCTAssertEqual(m.strokes[0].points.count, 1, "20pt of travel is below the stamp spacing")
        m.extendStroke(to: CGPoint(x: 200, y: 0))
        XCTAssertEqual(m.strokes[0].points.count, 2)
        m.clearMagic()
        XCTAssertTrue(m.strokes.isEmpty)
    }

    func testErasingProducesEraseStrokes() {
        let m = DrawingModel()
        m.erasing = true
        m.beginStroke(at: .zero)
        XCTAssertEqual(m.strokes.last?.kind, .erase)
    }

    func testPaletteSizesMatchAndroid() {
        XCTAssertEqual(DrawingPalette.paintBrush.count, 81)
        XCTAssertEqual(DrawingPalette.pencil.count, 44)
    }
}
