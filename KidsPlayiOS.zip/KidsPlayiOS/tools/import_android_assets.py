#!/usr/bin/env python3
"""
Copies artwork from your Android project into the iOS asset catalog.

    python3 tools/import_android_assets.py \
        --android-res  ../KidsPlay/app/src/main/res \
        --drawing-easy ../KidsPlay/kidsdrawing/src/main/assets/easy \
        --drawing-hard ../KidsPlay/kidsdrawing/src/main/assets/hard

* Every drawable the iOS code refers to (see REQUIRED below) is looked up in all `drawable*` folders of
  each --android-res, the highest density wins, .webp is converted to .png, and Android <vector> XML is
  converted to SVG (Xcode keeps it as vector art).
* Names in Android are already valid asset names (lowercase + underscore), so the Swift code uses them as-is.
* Prints a list of anything it could not find. Missing art shows a friendly placeholder in the app.

Needs:  pip install pillow
"""
import argparse, json, re, shutil, sys, xml.etree.ElementTree as ET
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    sys.exit("Please run:  pip install pillow")

ROOT = Path(__file__).resolve().parent.parent
XCASSETS = ROOT / "KidsPlay" / "Assets.xcassets"
DRAWINGS = ROOT / "KidsPlay" / "Resources" / "Drawings"
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

DENSITY_SCALE = {"mdpi": 1, "hdpi": 2, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 3, "nodpi": 3, "": 3}
DENSITY_RANK = {"": 0, "nodpi": 0, "mdpi": 1, "hdpi": 2, "xhdpi": 3, "xxhdpi": 4, "xxxhdpi": 5}


def required_names():
    names = set((ROOT / "tools" / "required_images.txt").read_text().split())
    names |= {"blocks", "play", "quiz", "math"}                                   # home top tiles
    names |= {f"home_{n}" for n in ["alphabet", "number", "color", "shape", "animal", "birds", "flower", "fruits",
                                    "month", "vegetable", "body_parts", "clothes", "country", "food", "geometry",
                                    "house", "jobs", "school", "sports", "vehicle", "golden"]}
    names |= {"line_standing", "line_sleeping", "line_slanting", "line_zigzag", "line_curved", "line_wavy"}
    names |= {"vt_abc", "vt_number", "vt_animal", "vt_shape", "vt_color"}
    names |= {"please", "thank_you", "sorry"}
    numbers = "one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty".split()
    names |= {f"{w}_{i + 1}" for i, w in enumerate(numbers)}
    names |= {"a_apple", "b_ball", "c_cat", "d_dog", "e_elephant"}
    # dedicated matching-game artwork: <letter>_<word> - optional, falls back to the flash-card picture
    return sorted(names)


# ---------- Android <vector> -> SVG --------------------------------------------------------------

def _color(value):
    if not value:
        return None, 1.0
    v = value.strip()
    if v.startswith("#") and len(v) == 9:      # #AARRGGBB
        return "#" + v[3:], int(v[1:3], 16) / 255
    if v.startswith("#") and len(v) == 4:      # #RGB
        return "#" + "".join(c * 2 for c in v[1:]), 1.0
    return v, 1.0


def vector_to_svg(xml_path: Path) -> str:
    root = ET.parse(xml_path).getroot()
    if root.tag != "vector":
        raise ValueError("not a <vector>")
    def dim(name):
        return float(re.sub(r"[^0-9.]", "", root.get(ANDROID_NS + name, "24")))
    w, h = dim("width"), dim("height")
    vw, vh = float(root.get(ANDROID_NS + "viewportWidth", w)), float(root.get(ANDROID_NS + "viewportHeight", h))
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:g}" height="{h:g}" viewBox="0 0 {vw:g} {vh:g}">']
    for path in root.iter("path"):
        attrs = {"d": path.get(ANDROID_NS + "pathData", "")}
        fill, fill_a = _color(path.get(ANDROID_NS + "fillColor"))
        stroke, stroke_a = _color(path.get(ANDROID_NS + "strokeColor"))
        attrs["fill"] = fill or "none"
        if fill and fill_a < 1: attrs["fill-opacity"] = f"{fill_a:.3f}"
        if stroke:
            attrs["stroke"] = stroke
            attrs["stroke-width"] = path.get(ANDROID_NS + "strokeWidth", "1")
            if stroke_a < 1: attrs["stroke-opacity"] = f"{stroke_a:.3f}"
            if path.get(ANDROID_NS + "strokeLineCap"): attrs["stroke-linecap"] = path.get(ANDROID_NS + "strokeLineCap")
            if path.get(ANDROID_NS + "strokeLineJoin"): attrs["stroke-linejoin"] = path.get(ANDROID_NS + "strokeLineJoin")
        if path.get(ANDROID_NS + "fillType") == "evenOdd": attrs["fill-rule"] = "evenodd"
        out.append("  <path " + " ".join(f'{k}="{v}"' for k, v in attrs.items()) + "/>")
    out.append("</svg>")
    return "\n".join(out)


# ---------- catalog writing ----------------------------------------------------------------------

def write_root_contents():
    XCASSETS.mkdir(parents=True, exist_ok=True)
    (XCASSETS / "Contents.json").write_text(json.dumps({"info": {"version": 1, "author": "xcode"}}, indent=2))


def write_imageset(name, files):
    """files: list of (Path, scale or None, ext)"""
    folder = XCASSETS / f"{name}.imageset"
    if folder.exists():
        shutil.rmtree(folder)
    folder.mkdir(parents=True)
    images, properties = [], {}
    for i, (src, scale, ext) in enumerate(files):
        filename = f"{name}{'' if scale is None else f'@{scale}x'}.{ext}"
        shutil.copy(src, folder / filename)
        entry = {"idiom": "universal", "filename": filename}
        if scale: entry["scale"] = f"{scale}x"
        images.append(entry)
    if files and files[0][2] == "svg":
        properties = {"preserves-vector-representation": True}
    contents = {"images": images, "info": {"version": 1, "author": "xcode"}}
    if properties: contents["properties"] = properties
    (folder / "Contents.json").write_text(json.dumps(contents, indent=2))


def convert_raster(src: Path, tmp: Path) -> Path:
    if src.suffix.lower() == ".png":
        return src
    dest = tmp / (src.stem + ".png")
    with Image.open(src) as im:
        im.convert("RGBA").save(dest, "PNG", optimize=True)
    return dest


def find_candidates(res_dirs, name):
    found = []
    for res in res_dirs:
        for folder in sorted(res.glob("drawable*")):
            m = re.match(r"drawable(?:-[a-z0-9]+)*?(?:-(mdpi|hdpi|xhdpi|xxhdpi|xxxhdpi|nodpi))?$", folder.name)
            density = m.group(1) if m and m.group(1) else ""
            for ext in ("png", "webp", "jpg", "jpeg", "xml"):
                p = folder / f"{name}.{ext}"
                if p.exists():
                    found.append((DENSITY_RANK.get(density, 0), density, p))
    return sorted(found, key=lambda t: t[0], reverse=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--android-res", action="append", type=Path, default=[], help="an Android `res` folder (repeatable)")
    ap.add_argument("--drawing-easy", type=Path)
    ap.add_argument("--drawing-hard", type=Path)
    ap.add_argument("--only-missing", action="store_true", help="don't overwrite image sets that already exist")
    args = ap.parse_args()

    write_root_contents()
    tmp = ROOT / ".import_tmp"
    tmp.mkdir(exist_ok=True)
    imported, missing, skipped = 0, [], 0

    for name in required_names():
        if args.only_missing and (XCASSETS / f"{name}.imageset").exists():
            skipped += 1
            continue
        candidates = find_candidates(args.android_res, name)
        if not candidates:
            missing.append(name)
            continue
        _, density, best = candidates[0]
        try:
            if best.suffix == ".xml":
                svg = tmp / f"{name}.svg"
                svg.write_text(vector_to_svg(best))
                write_imageset(name, [(svg, None, "svg")])
            else:
                # keep every density we have, converted to png
                by_scale = {}
                for rank, dens, path in candidates:
                    if path.suffix == ".xml": continue
                    by_scale.setdefault(DENSITY_SCALE[dens], path)
                files = [(convert_raster(p, tmp), s, "png") for s, p in sorted(by_scale.items())]
                write_imageset(name, files if len(files) > 1 else [(files[0][0], files[0][1] if files[0][1] in (1, 2, 3) else 3, "png")])
            imported += 1
        except Exception as exc:                       # keep going, report at the end
            print(f"  ! {name}: {exc}")
            missing.append(name)

    for label, src, sub in (("easy", args.drawing_easy, "easy"), ("hard", args.drawing_hard, "hard")):
        if not src:
            continue
        dest = DRAWINGS / sub
        dest.mkdir(parents=True, exist_ok=True)
        count = 0
        for f in sorted(src.iterdir()):
            if f.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
                out = dest / (f.stem + (".png" if f.suffix.lower() == ".webp" else f.suffix.lower()))
                if f.suffix.lower() == ".webp":
                    with Image.open(f) as im: im.convert("RGBA").save(out, "PNG", optimize=True)
                else:
                    shutil.copy(f, out)
                count += 1
        print(f"drawing/{label}: {count} pictures")

    shutil.rmtree(tmp, ignore_errors=True)
    print(f"\nimported {imported} image sets" + (f", skipped {skipped} existing" if skipped else ""))
    if missing:
        print(f"{len(missing)} not found (placeholder art will show): ")
        print("  " + ", ".join(missing[:60]) + (" ..." if len(missing) > 60 else ""))
        (ROOT / "tools" / "missing_images.txt").write_text("\n".join(missing))


if __name__ == "__main__":
    main()
